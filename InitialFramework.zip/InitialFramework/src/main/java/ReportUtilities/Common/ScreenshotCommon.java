package ReportUtilities.Common;

import ReportUtilities.Constants.ReportContants;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.time.LocalDateTime;
import java.util.Date;

;
public class ScreenshotCommon
{
	private static final Logger logger =LoggerFactory.getLogger(ScreenshotCommon.class.getName()); 

	public void GetEntireScreenshot(String screenshotPath, WebDriver driver) throws IOException
	{

		try {
			JavascriptExecutor jsExec = (JavascriptExecutor)driver;

			//Returns a Long, Representing the Height of the window’s content area.
			Long windowHeight = (Long) jsExec.executeScript("return window.innerHeight;");

			//Returns a Long, Representing the Height of the complete WebPage a.k.a. HTML document.
			Long webpageHeight = (Long) jsExec.executeScript("return document.body.scrollHeight;"); 

			//Marker to keep track of the current position of the scroll point
			//Long currentWindowScroll = Long.valueOf(0);
			//Using java's boxing feature to create a Long object from native long value.

			Long currentWindowScroll = 0L;

			do{
				//System.out.println(windowHeight + ", " + webpageHeight + ", " + currentWindowScroll);

				jsExec.executeScript("window.scrollTo(0, " + currentWindowScroll + ");");

				Actions act = new Actions(driver);
				act.pause(5000).perform();

				Date timestamp = new Date();

				File tempScreenshot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);

				// Read the screenshot image
		        BufferedImage image = ImageIO.read(tempScreenshot);

		        // Create a graphics context on the image
		        Graphics2D graphics = image.createGraphics();

		        // Set the timestamp on the image
		        graphics.drawString(timestamp.toString(), 10, 20); // Adjust coordinates as needed

		        // Save the modified screenshot
//		        File screenshotWithTimestamp = new File("screenshot_with_timestamp.png");
		        
				//----------
				//Unique File Name For Each Screenshot
				File destination = new File(screenshotPath);
				ImageIO.write(image, "png", tempScreenshot);

				Files.copy( tempScreenshot.toPath(), destination.toPath());

				currentWindowScroll = currentWindowScroll + windowHeight;

			}while(currentWindowScroll <= webpageHeight);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		}
	}


	/// <summary>
	/// This method captures the screenshot of the Current Page
	/// </summary>
	/// Author: Jigesh Shah
	/// <param name="driver">WebDriver Instance</param>
	/// <param name="path">Location to capture Screenshot</param>
	/// <returns></returns>
	public void GetScreenShot(String screenshotPath, WebDriver driver) throws Exception
	{
		try
		{
			TakesScreenshot scrst = ((TakesScreenshot)driver);

			Date timestamp = new Date();
			// Call getScreenshotAs method to create an image file
			File SrcFile = scrst.getScreenshotAs(OutputType.FILE);

			// Read the screenshot image
	        BufferedImage image = ImageIO.read(SrcFile);

	        // Create a graphics context on the image
	        Graphics2D graphics = image.createGraphics();

	        // Set the timestamp on the image
	        Font font = new Font("Arial", Font.BOLD, 24); // Adjust the font name and size as needed
	        graphics.setFont(font);
	        graphics.setColor(Color.RED);
	        graphics.drawString(timestamp.toString(), 10, 20); // Adjust coordinates as needed

			// Move image file to the new destination
			File DestFile = new File(screenshotPath);

			ImageIO.write(image, "png", SrcFile);
			// Copy file at the destination
			FileUtils.copyFile(SrcFile, DestFile);		
		}
		catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		}
	}

	public static String getCurrentDate() throws Exception
	{
		try
		{
			LocalDateTime today = LocalDateTime.now();

			String date = today.toLocalDate().toString();
			date = date.replace(":", "_");
			date = date.replace(" ", "_");
			date = date.replace(".", "_");
			date = date.replace("-", "_");
			return date;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw e;
		}
	}


	public static String getCurrentTime() throws Exception
	{
		try
		{
			LocalDateTime today = LocalDateTime.now();

			String result = today.toLocalTime().toString();

			result = result.replace(":", "_");
			result = result.replace(" ", "_");
			result = result.replace(".", "_");
			return result;

		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw e;
		}

	}

	public String CreateDirectory(String DirectoryPath, String DirectoryName) throws Exception
	{
		try
		{
			String DirectoryFulPath = DirectoryPath + "/" + DirectoryName;
			File dir = new File(DirectoryFulPath);
			if (!dir.exists()) dir.mkdirs();

			return DirectoryFulPath;

		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw e;

		}
	}

	public String CaptureScreenShot(WebDriver driver, String TestCaseName) throws Exception
	{

		String ScreenshotPath = CreateDirectory(ReportContants.ResultsFolder, "Screenshot");
		String ScreenShotFileName=TestCaseName + "_" + getCurrentTime() + ".jpeg";
		ScreenShotFileName=ScreenShotFileName.replace(" ", "_");
		ScreenshotPath = ScreenshotPath + "/" +ScreenShotFileName;
		if (ReportContants.isFullPageScreenShot)
		{
			GetEntireScreenshot(ScreenshotPath, driver);
		}
		else
		{
			GetScreenShot(ScreenshotPath, driver);
		}

		return ScreenshotPath;
	}
}
