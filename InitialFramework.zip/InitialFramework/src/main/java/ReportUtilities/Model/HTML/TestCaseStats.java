package ReportUtilities.Model.HTML;

import com.fasterxml.jackson.annotation.JsonProperty;

public class TestCaseStats {
	@JsonProperty("passed")
    private int passed;
	@JsonProperty("failed")
    private int failed;
	@JsonProperty("pending")
    private int pending;
	@JsonProperty("skipped")
    private int skipped;
	@JsonProperty("inprogress")
    private int inprogress;
    
    public TestCaseStats()
    {
    	
    }
    
	public int getPassed() {
		return passed;
	}
	public void setPassed(int passed) {
		this.passed = passed;
	}
	public int getFailed() {
		return failed;
	}
	public void setFailed(int failed) {
		this.failed = failed;
	}
	public int getPending() {
		return pending;
	}
	public void setPending(int pending) {
		this.pending = pending;
	}
	public int getSkipped() {
		return skipped;
	}
	public void setSkipped(int skipped) {
		this.skipped = skipped;
	}

	public int getInProgress() {
		// TODO Auto-generated method stub
		return inprogress;
	}
	
	public void setInProgress(int inprogress) {
		this.inprogress = inprogress;
	}

    // Constructor, getters, and setters
}
