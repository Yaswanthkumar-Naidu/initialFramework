package ReportUtilities.Model.HTML;


import ReportUtilities.Common.ReportCommon;
import ReportUtilities.Constants.HTMLReportContants;
import ReportUtilities.Constants.HTMLReportContants.HTMLTCStatus;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.exc.StreamWriteException;
import com.fasterxml.jackson.databind.DatabindException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;



public class TestManager {
	@JsonProperty("testCaseStats")
    private static TestCaseStats testCaseStats = new TestCaseStats();
	@JsonProperty("modules")
    private static List<Module> modules = new ArrayList<>();
	@JsonProperty("browsers")
    private static List<Browser> browsers = new ArrayList<>();
	@JsonProperty("testCases")
    private static List<TestCase> testCases = new ArrayList<>();
	
	

	private static final String Status_Pending = "Pending";
	private static final String Status_InProgress = "InProgess";
	private static final String Status_Passed = "Passed";
	private static final String Status_Failed = "Failed";
	private static final String Status_Skipped = "Skipped";

	
	
	public static void addTestStep(String testCaseName, String moduleName, String browserName, TestStep testStep) throws StreamWriteException, DatabindException, IOException {
	    for (TestCase testCase : testCases) {
	        if (testCase.getTestCaseName().equals(testCaseName) &&
	            testCase.getModule().equals(moduleName) &&
	            testCase.getBrowser().equals(browserName)) {
	            
	            // Check the current size of the test steps list
	            int currentStepCount =0;
	            
	            if(testCase.getTestSteps()!=null)
	            {
	            	 currentStepCount =testCase.getTestSteps().size();
	            }
	            	

	            // Set the step number for the new test step
	            testStep.setStepNo(currentStepCount + 1);

	            if(currentStepCount==0) {
	            	updateTestStartTime(testCase);
	            }
	            
	            // Add the test step to the test case
	            testCase.getTestSteps().add(testStep);

	            // Update test step counts and current step details here
	            updateTestStepCounts(testCase);
	            updateCurrentStepDetails(testCase, testStep);
	            
	            String TestCaseFilePath= HTMLReportContants.HTMLReportsDir+"/"+ testCaseName+ "_"
	            		+ moduleName+ "_" + browserName + "/" +HTMLReportContants.TestCaseJSON;
	            ObjectMapper mapper = new ObjectMapper();
	            mapper.writeValue(new File(TestCaseFilePath), testCase);
	            break;
	        }
	    }
	}


	

	// Method to update test step counts for a test case
	private static void updateTestStepCounts(TestCase testCase) {
	    int passedCount = 0;
	    int failedCount = 0;
	    for (TestStep step : testCase.getTestSteps()) {
	        if (step.getStatus().equals("Passed") || step.getStatus().equals("PASS")) {
	            passedCount++;
	        } else if (step.getStatus().equals("Failed") || step.getStatus().equals("FAIL")) {
	            failedCount++;
	        }
	    }
	    testCase.setPassed(passedCount);
	    testCase.setFailed(failedCount);
	    testCase.setTotalSteps(testCase.getTestSteps().size());
	}
	
	//Method to update start time of testcase
	private static void updateTestStartTime(TestCase testCase) {
		ReportCommon reportCommon = new ReportCommon();
		testCase.setStartTime(reportCommon.ConvertLocalDateTimetoSQLDateTime(LocalDateTime.now()));

	}
	private static void updateTestEndTime(TestCase testCase) {
		ReportCommon reportCommon = new ReportCommon();
		testCase.setEndTime(reportCommon.ConvertLocalDateTimetoSQLDateTime(LocalDateTime.now()));

	}

	// Method to update current step details for a test case
	private static void updateCurrentStepDetails(TestCase testCase, TestStep currentStep) {
	    CurrentStepData currentStepData = new CurrentStepData();
	    currentStepData.setCurrentStep(currentStep.getDescription());
	    currentStepData.setStatus(currentStep.getStatus());
	    testCase.setStatus(currentStep.getStatus());
	    testCase.setCurrentStepData(currentStepData);
	}

    public static void addTestCase(String testCaseName, String moduleName, String browserName) {
        TestCase newTestCase = new TestCase(testCaseName, moduleName, browserName, getTCStatus(HTMLTCStatus.Pending));
        testCases.add(newTestCase);
        updateStats(moduleName, browserName, getTCStatus(HTMLTCStatus.Pending), "increase");
        String TCDir=HTMLReportContants.HTMLReportsDir+"/"+ testCaseName+ "_" 	+ moduleName+ "_" + browserName;
        CreateDirectory(TCDir);
        CreateFile(TCDir +"/" + HTMLReportContants.TestCaseHTML , HTMLReportContants.TestCaseData_HTML);
        WriteFileLineByLine(TCDir +"/" + HTMLReportContants.TestCaseCSS_Output , HTMLReportContants.TestCaseData_CSS);
        WriteFileLineByLine(TCDir +"/" + HTMLReportContants.TestCaseJS_Output , HTMLReportContants.TestCaseData_JS);
    }

    public static void updateTestCaseStatus(String testCaseName, String moduleName, String browserName, HTMLTCStatus htmlTCStatus) {
        for (TestCase testCase : testCases) {
        	 if (testCase.getTestCaseName().equals(testCaseName) &&
     	            testCase.getModule().equals(moduleName) &&
     	            testCase.getBrowser().equals(browserName)) {
     	            
                String oldStatus = testCase.getStatus();
                if(testCase.getStatus().equalsIgnoreCase("FAIL")) {
                	testCase.setStatus(HTMLTCStatus.Failed.toString());
                }else {
                	testCase.setStatus(getTCStatus(htmlTCStatus));
                }
                
                updateStats(testCase.getModule(), testCase.getBrowser(), oldStatus, "decrease");
                updateStats(testCase.getModule(), testCase.getBrowser(), testCase.getStatus(), "increase");
	            updateTestEndTime(testCase);
	            String TestCaseFilePath= HTMLReportContants.HTMLReportsDir+"/"+ testCaseName+ "_"
	            		+ moduleName+ "_" + browserName + "/" +HTMLReportContants.TestCaseJSON;
	            ObjectMapper mapper = new ObjectMapper();
	            try {
					mapper.writeValue(new File(TestCaseFilePath), testCase);
				} catch (StreamWriteException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (DatabindException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
                break;
            }
        	 
        	 
        }
    }

    private static void updateStats(String moduleName, String browserName, String status, String operation) {
        // Logic to find or create Module and Browser
        Module module = findOrCreateModule(moduleName);
        Browser browser = findOrCreateBrowser(browserName);

        // Update counts for Module and Browser
        updateCount(module,status, operation);
        updateCount(browser, status, operation);

        // Update global TestCaseStats
        updateGlobalCount(testCaseStats, status, operation);
        
        generateJson(HTMLReportContants.SummaryJSONFilePath);
    }

    private static Module findOrCreateModule(String moduleName) {
        for (Module module : modules) {
            if (module.getName().equals(moduleName)) {
                return module;
            }
        }
        Module newModule = new Module(moduleName, 0, 0, 0, 0);
        modules.add(newModule);
        return newModule;
    }

    private static Browser findOrCreateBrowser(String browserName) {
        for (Browser browser : browsers) {
            if (browser.getName().equals(browserName)) {
                return browser;
            }
        }
        Browser newBrowser = new Browser(browserName, 0, 0, 0, 0);
        browsers.add(newBrowser);
        return newBrowser;
    }

    private static void updateCount(Object obj, String status, String operation) {
        int change = operation.equals("increase") ? 1 : -1;
        if (obj instanceof Module) {
            Module module = (Module) obj;
            switch (status) {
                case Status_Passed: module.setPassed(module.getPassed() + change); break;
                case Status_InProgress: module.setInProgress(module.getInProgress() + change); break;
                case Status_Failed: module.setFailed(module.getFailed() + change); break;
                case Status_Pending: module.setPending(module.getPending() + change); break;
                case Status_Skipped: module.setSkipped(module.getSkipped() + change); break;
            }
            if(status == "Failed") {
            	module.setPending(module.getPending() - change);
            }
        } else if (obj instanceof Browser) {
            Browser browser = (Browser) obj;
            switch (status) {
                case Status_Passed: browser.setPassed(browser.getPassed() + change); break;
                case Status_InProgress: browser.setInProgress(browser.getInProgress() + change); break;
                case Status_Failed: browser.setFailed(browser.getFailed() + change); break;
                case Status_Pending: browser.setPending(browser.getPending() + change); break;
                case Status_Skipped: browser.setSkipped(browser.getSkipped() + change); break;
            }
            if(status == "Failed") {
            	browser.setPending(browser.getPending() - change);
            }
        }
        
    }

    private static void updateGlobalCount(TestCaseStats stats, String status, String operation) {
        int change = operation.equals("increase") ? 1 : -1;
        switch (status) {
        
        
            case Status_Passed: stats.setPassed(stats.getPassed() + change); break;
            case Status_InProgress: stats.setInProgress(stats.getInProgress() + change); break;
            case Status_Failed: stats.setFailed(stats.getFailed() + change); break;
            case Status_Pending: stats.setPending(stats.getPending() + change); break;
            case Status_Skipped: stats.setSkipped(stats.getSkipped() + change); break;
        }
        if(status == "Failed") {
        	stats.setPending(stats.getPending() - change);
        }
    }

    
    public static void CreateDirectory(String FilePath)
    {
    	File dir = new File(FilePath);
        if (!dir.exists()) dir.mkdirs();
    }
    
    public static void CreateFile(String FilePath,String Data)
    {
    	try
		{

			 BufferedWriter writer = new BufferedWriter(new FileWriter(FilePath));
		    writer.write(Data);
			    
			    writer.close();

			
		}
		
		catch (Exception e)
		{
		
		}
    }
    
    
    public static void generateJson(String filePath) {
        ObjectMapper mapper = new ObjectMapper();
        DataWrapper data = new DataWrapper(testCaseStats, modules, browsers, testCases);

        try {
            // Write JSON to a file
            mapper.writeValue(Paths.get(filePath).toFile(), data);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public static String getTCStatus (HTMLTCStatus htmlTCStatus)
    {
    	String status="Pending";
    	
    	switch (htmlTCStatus) {
        case Passed: return Status_Passed;
        case InProgress: return Status_InProgress;
        case Failed: return Status_Failed;
        case Pending: return Status_Pending;
        case Skipped: return Status_Skipped;
    }
    	
    	
    	return status;
    }
    
    // Inner class to wrap all data
    private static class DataWrapper {
        public TestCaseStats testCaseStats;
        public List<Module> modules;
        public List<Browser> browsers;
        public List<TestCase> testCases;

        public DataWrapper(TestCaseStats stats, List<Module> mod, List<Browser> brws, List<TestCase> tcs) {
            this.testCaseStats = stats;
            this.modules = mod;
            this.browsers = brws;
            this.testCases = tcs;
        }
    }
    
	public static void WriteFileLineByLine(String FilePath,ArrayList<String> FileContent)
	{

		try (BufferedWriter writer = new BufferedWriter(new FileWriter(FilePath))) {
	        for (String line : FileContent) {
	            writer.write(line);
	            writer.newLine(); // To add a newline after each line
	        }
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}

}
