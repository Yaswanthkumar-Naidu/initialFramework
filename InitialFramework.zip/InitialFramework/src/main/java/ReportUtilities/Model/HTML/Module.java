package ReportUtilities.Model.HTML;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Module {
	@JsonProperty("name")
    private String name;
	@JsonProperty("passed")
    private int passed;
	@JsonProperty("failed")
    private int failed;
	@JsonProperty("pending")
    private int pending;
	@JsonProperty("skipped")
    private int skipped;
	@JsonProperty("inprogress")
	private int inprogress;

    public Module()
    {
    	
    }
    		
    
    public Module(String name, int passed, int failed, int pending, int skipped) {
        this.name = name;
        this.passed = passed;
        this.failed = failed;
        this.pending = pending;
        this.skipped = skipped;
    }
    
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPassed() {
		return passed;
	}
	public void setPassed(int passed) {
		this.passed = passed;
	}
	public int getFailed() {
		return failed;
	}
	public void setFailed(int failed) {
		this.failed = failed;
	}
	public int getPending() {
		return pending;
	}
	public void setPending(int pending) {
		this.pending = pending;
	}
	public int getSkipped() {
		return skipped;
	}
	public void setSkipped(int skipped) {
		this.skipped = skipped;
	}
	
	
	public int getInProgress() {
		// TODO Auto-generated method stub
		return inprogress;
	}
	
	public void setInProgress(int inprogress) {
		this.inprogress = inprogress;
	}

}
