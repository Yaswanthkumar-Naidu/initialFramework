package ReportUtilities.Model;

import ReportUtilities.ExtentReport.ExtentConstants.TestStepStatus;

import java.time.LocalDateTime;

public class InterfaceTCDetails
{
    public long TestRunId;
    public String TestCaseId;
    public String Module;
    public int Iteration;
    public String InterfaceName = "";
    public String RequestData;
    public String ResponseData;
    public LocalDateTime StartTime;
    public LocalDateTime EndTime;
    public int Duration;
    public String testCaseStatus = "";
    public TestStepStatus TestCaseStatus;
    public String StatusCode = "";
    public String ErrorMessage = "";
    public String FileFormat = "";


    public void setInterfaceTCDetails(long TestRunId, String TestCaseId,
        String ModuleName, String InterfaceName, int Iteration,
       String RequestData,String ResponseData,String FileFormat,LocalDateTime StartTime,
       LocalDateTime EndTime, String TCStatus,String StatusCode,String ErrorMessage)
    {
        this.TestRunId = TestRunId;
        this.TestCaseId = TestCaseId;
        this.Module = ModuleName;
        this.InterfaceName = InterfaceName;
        this.Iteration = Iteration;
        this.RequestData = RequestData;
        this.ResponseData = ResponseData;
        this.StartTime = StartTime;
        this.EndTime = StartTime;
        this.testCaseStatus = TCStatus;
        this.TestCaseStatus = setTestCaseStatus(TCStatus);
        this.FileFormat = FileFormat;
        this.StartTime = StartTime;
        this.EndTime = EndTime;
        this.Duration = EndTime.getSecond() - StartTime.getSecond();
       
        this.StatusCode = StatusCode;
        this.ErrorMessage = ErrorMessage;
    }

    public TestStepStatus setTestCaseStatus(String TCStatus)
    {
        try
        {
            if (TCStatus.toUpperCase().equals("PASS"))
            {
                TestCaseStatus = TestStepStatus.PASS;
            }
            else if (TCStatus.toUpperCase().equals("PASSED"))
            {
                TestCaseStatus = TestStepStatus.PASS;
            }
            else if (TCStatus.toUpperCase().equals("FAIL"))
            {
                TestCaseStatus = TestStepStatus.FAIL;
            }
            else if (TCStatus.toUpperCase().equals("FAILED"))
            {
                TestCaseStatus = TestStepStatus.FAIL;
            }
            else
            {
                TestCaseStatus = TestStepStatus.SKIP;
            }
        }
        catch (Exception e)
        {
            TestCaseStatus = TestStepStatus.SKIP;
        }

        return TestCaseStatus;


    }

    public TestStepStatus getTestCaseStatus()
    {
        return TestCaseStatus;
    }
    }

