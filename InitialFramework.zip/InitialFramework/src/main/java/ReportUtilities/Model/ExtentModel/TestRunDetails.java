package ReportUtilities.Model.ExtentModel;


import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.UUID;


public class TestRunDetails
{

	@JsonProperty("TestCaseRepository")
	static ArrayList<HashMap<UUID, TestCaseDetails>> TestCaseRepository = new ArrayList<HashMap<UUID, TestCaseDetails>>();
	@JsonProperty("TestCaseMapping")

	static ArrayList<HashMap<String, UUID>> TestCaseMapping = new ArrayList<HashMap<String, UUID>>();


	public static  ArrayList<HashMap<UUID, TestCaseDetails>>  getTestCaseRepository()
	{
		return TestCaseRepository;
	}
	
	public TestRunDetails()
	{
		
	}

}