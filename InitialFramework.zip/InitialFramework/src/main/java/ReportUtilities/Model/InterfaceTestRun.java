package ReportUtilities.Model;

import java.time.LocalDateTime;
import java.util.ArrayList;

public class InterfaceTestRun
{
    public long TestRunId;
    public String TestRunName;
    public String Environment;
    public LocalDateTime TestRunDate;

    public ArrayList<InterfaceTCDetails> interfaceTCDetails = new ArrayList<InterfaceTCDetails>();
	public String ExecutedBy;
    public boolean ShareAttachmentForPassedTestCases=false;

    public void setInterfaceTestRun(long TestRunId,String Environment, String TestRunName)
    {
        this.TestRunId = TestRunId;
        this.Environment = Environment;
        this.TestRunName = TestRunName;
        TestRunDate = LocalDateTime.now();
    }

    public long getTestRunId()
    {
        return TestRunId;
    }
}
