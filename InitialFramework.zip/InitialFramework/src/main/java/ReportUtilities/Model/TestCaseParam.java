package ReportUtilities.Model;

public class TestCaseParam
{
	public enum TestCaseType {Prereq,Main};
    public String TestCaseName ;
    public String TestCaseDescription ;
    public String ModuleName ;
    public String TestCaseCategory;
    public TestCaseType testCaseType= TestCaseType.Main;
  
    ///*******temp changes8888////
    public String CaseNumber ;
    public String ApplicationNumber ;
    
    
    
    ///**************************//



    public int Iteration = 1;
    public String Browser;

}
