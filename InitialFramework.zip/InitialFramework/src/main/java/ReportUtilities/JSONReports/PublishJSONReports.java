package ReportUtilities.JSONReports;

import ReportUtilities.Model.ExtentModel.TestCaseDetails;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.UUID;

public class PublishJSONReports {



	public void LogJSONResults(ArrayList<HashMap<UUID, TestCaseDetails>> TestCaseRepository,String ReportPath) throws Exception
	{

	try {
		ReportPath= ReportPath+"/JSONReports";
		File dir = new File(ReportPath);
        if (!dir.exists()) dir.mkdirs();

        
		if (TestCaseRepository != null)
		{

			for (HashMap<UUID,TestCaseDetails> DictTC : TestCaseRepository)
			{
				TestCaseDetails testCaseDetails = DictTC.values().stream().findFirst().get();
				JSONUtility jsonUtility = new JSONUtility();
				String TCName=testCaseDetails.TestCaseName.replace(" ", "");
				String ModuleName=testCaseDetails.Module.replace(" ", "");
			
				String TCPath=ReportPath+"/"+ TCName+"_"+ModuleName+"_"+testCaseDetails.Browser+ "_"+ testCaseDetails.Iteration + ".json";
				jsonUtility.DeSerializeTCDataWriteToFile(testCaseDetails, TCPath);
			}
		}
		
		//TestCase Details
	
	}
		
		//TestCase Details
		
		catch(Exception e) 
		{
			throw e;
		}
	
	}
	

}
