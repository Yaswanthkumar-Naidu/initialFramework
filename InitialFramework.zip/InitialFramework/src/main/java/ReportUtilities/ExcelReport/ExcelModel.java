package ReportUtilities.ExcelReport;


import java.util.ArrayList;
import java.util.HashMap;

public class ExcelModel
{
	public String SheetName = "";
	public ArrayList<String> HeaderData = new ArrayList<String>();
	public HashMap<Integer, ArrayList<String>> TableData = new HashMap<Integer, ArrayList<String>>();
}