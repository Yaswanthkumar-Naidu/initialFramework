package ReportUtilities.ExcelReport;


import ReportUtilities.Common.ReportCommon;
import ReportUtilities.Model.ExtentModel.TestStepDetails;
import ReportUtilities.Model.ExtentModel.TestStepDetails.TestStepType;
import ReportUtilities.TestResultModel.BrowserResult;
import ReportUtilities.TestResultModel.ModuleResult;
import ReportUtilities.TestResultModel.TestCaseResult;
import org.apache.poi.common.usermodel.HyperlinkType;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileOutputStream;
import java.util.ArrayList;

public class ExcelReportCommon {

	
	public Workbook createWorkbook() throws Exception
	{
		
        Workbook workbook = new XSSFWorkbook();     // new HSSFWorkbook() for generating `.xls` file

        return workbook;
	}
	
	public CreationHelper createExcelHelper(Workbook workbook)throws Exception
	{
		CreationHelper createHelper = workbook.getCreationHelper();
		return createHelper;
		
	}
	
	/**
	 * @param workbook
	 * @param SheetName
	 */
	public Sheet createSheet(Workbook workbook,String SheetName) {
		  Sheet sheet = workbook.createSheet(SheetName);
		  return sheet;
	}
	
	public void createHeader(Workbook workbook, Sheet sheet,ArrayList<String> columns,ArrayList<Integer> columnSize ,int StartRow)
	{
	        // Create a Row
	        Row headerRow = sheet.createRow(StartRow);
	        CellStyle headerStyle= getHeaderCellStyle(workbook);
	        // Creating cells
	        for(int i = 0; i < columns.size(); i++) {
	            Cell cell = headerRow.createCell(i);
	            cell.setCellValue(columns.get(i));
	            cell.setCellStyle(headerStyle);
	            sheet.setColumnWidth(i, columnSize.get(i));
	        }

	}
	
	public void AddTestStepDetails(Workbook workbook, Sheet sheet,CreationHelper createHelper,ArrayList<TestStepDetails> rowdata)
	{
	
        int rowNum = 1;
        int SNumber = 1;
        for(TestStepDetails teststepmodel : rowdata) {
            Row row = sheet.createRow(rowNum++);


            if((teststepmodel.testStepType== TestStepType.Module) || 
            	(teststepmodel.testStepType== TestStepType.Screen)|| 
            	(teststepmodel.testStepType== TestStepType.Module_Screen) )
            {
            	String StepDetails="";
            
            	if(teststepmodel.testStepType== TestStepType.Module)
            	{
            		StepDetails="Module : "+ teststepmodel.ModuleName;
            	}

            	if(teststepmodel.testStepType== TestStepType.Screen)
            	{
            		StepDetails="Screen : "+ teststepmodel.ScreenName;
            	}

            	if(teststepmodel.testStepType== TestStepType.Module_Screen)
            	{
            		StepDetails="Module : "+ teststepmodel.ModuleName
            				+ " ===> Screen : "+ teststepmodel.ScreenName;
            	}

    	        Cell Cell_1 = row.createCell(0);
    	        Cell_1.setCellStyle(getLeftBorderStyle(workbook));

    	        Cell Cell_2 = row.createCell(1);
    	        Cell_2.setCellStyle(getNoSideBorderStyle(workbook));

    	        Cell Cell_3 = row.createCell(2);
    	        Cell_3.setCellValue(StepDetails);
    	        Cell_3.setCellStyle(getNoSideBorderStyle(workbook));

    	        Cell Cell_4 = row.createCell(3);
    	        Cell_4.setCellStyle(getNoSideBorderStyle(workbook));

    	        Cell Cell_5 = row.createCell(4);
    	        Cell_5.setCellStyle(getNoSideBorderStyle(workbook));


    	        Cell Cell_6 = row.createCell(5);
    	        Cell_6.setCellStyle(getNoSideBorderStyle(workbook));

    	        Cell Cell_7 = row.createCell(6);
    	        Cell_7.setCellStyle(getNoSideBorderStyle(workbook));

    	        Cell Cell_8 = row.createCell(7);
    	        Cell_8.setCellStyle(getNoSideBorderStyle(workbook));


    	        Cell Cell_9 = row.createCell(8);
    	        Cell_9.setCellStyle(getNoSideBorderStyle(workbook));

    	        Cell Cell_10 = row.createCell(9);
    	        Cell_10.setCellStyle(getRightBorderStyle(workbook));

            }
            else
            {
            
            CellStyle rowCellStyle =getGenericCellStyle(workbook);
            
	        Cell SNo = row.createCell(0);
            SNo.setCellValue(SNumber++);
            SNo.setCellStyle(getGenericCellStyleMiddle(workbook));


	        Cell StepName = row.createCell(1);
	        StepName.setCellValue(teststepmodel.StepName);
	        StepName.setCellStyle(rowCellStyle);

            
            row.createCell(2)
            .setCellValue(teststepmodel.StepDescription);
            
            Cell StepDesc = row.createCell(2); 
            StepDesc.setCellValue(teststepmodel.StepDescription);
            StepDesc.setCellStyle(rowCellStyle);


            if(teststepmodel.ExtentStatus.name().toUpperCase().contains("PASS"))
            {
            	   Cell passStatus = row.createCell(3);
            	   passStatus.setCellValue(teststepmodel.ExtentStatus.name());
            	   passStatus.setCellStyle(getPassCellStyle(workbook));
            	
            }

            else if(teststepmodel.ExtentStatus.name().toUpperCase().contains("FAIL"))
            {
            	   Cell failStatus = row.createCell(3);
            	   failStatus.setCellValue(teststepmodel.ExtentStatus.name());
            	   failStatus.setCellStyle(getFailCellStyle(workbook));
            	
            }
            else if(teststepmodel.ExtentStatus.name().toUpperCase().contains("INFO"))
            {
         	   Cell passStatus = row.createCell(3);
         	   passStatus.setCellValue("DONE");
         	   passStatus.setCellStyle(getGenericCellStyleMiddle(workbook));
         	
         }
            else
            {
                
                
                Cell status = row.createCell(3);
                status.setCellValue(teststepmodel.ExtentStatus.name());
                status.setCellStyle(getGenericCellStyleMiddle(workbook));


            }
             
            ReportCommon rcommon= new ReportCommon();
            
            Cell startTime = row.createCell(4);
            startTime.setCellValue(rcommon.ConvertLocalDateTimetoSQLDateTime(teststepmodel.StartTime));
            startTime.setCellStyle(getDateTimeCellStyle(workbook, createHelper));

            Cell endTime = row.createCell(5);
            endTime.setCellValue(rcommon.ConvertLocalDateTimetoSQLDateTime(teststepmodel.EndTime));
            endTime.setCellStyle(getDateTimeCellStyle(workbook, createHelper));

            
            Cell duration = row.createCell(6);
            duration.setCellValue(rcommon.getDuration(teststepmodel.StartTime, teststepmodel.EndTime));
            duration.setCellStyle(getGenericCellStyleMiddle(workbook));
            

            if(teststepmodel.ScreenShotData.equals("")==false)
            {
            	
                Cell Screenshot = row.createCell(7);
                //Screenshot.setCellValue(teststepmodel.ScreenShotData);
                
                try
                {
                Screenshot.setCellValue("Screenshot");
                Screenshot.setHyperlink(getHyperLinkScreenshot(workbook, createHelper, teststepmodel.ScreenShotData));
                Screenshot.setCellStyle(getHyperLinkCellStyle(workbook));
                }
                catch(Exception e)
                {
                    Screenshot.setCellValue("Missing Screenshot");
                  //  Screenshot.setHyperlink(getHyperLinkScreenshot(workbook, createHelper, teststepmodel.ScreenShotData));
                    Screenshot.setCellStyle(rowCellStyle);
                	
                }
                
            }
            else
            {
            	
            	
                Cell Screenshot = row.createCell(7);
                Screenshot.setCellValue("N\\A");
                Screenshot.setCellStyle(getGenericCellStyleMiddle(workbook));

            }
            
            if(teststepmodel.ErrorMessage.equals("")==false)
            {
            	
                Cell errorMessage = row.createCell(8);
                errorMessage.setCellValue(teststepmodel.ErrorMessage);
                errorMessage.setCellStyle(rowCellStyle);
            }
            else
            {
                Cell errorMessage = row.createCell(8);
                errorMessage.setCellValue("N\\A");
                errorMessage.setCellStyle(getGenericCellStyleMiddle(workbook));

            }
            
            if(teststepmodel.ErrorDetails.equals("")==false)
            {
                Cell errorDetails = row.createCell(9);
                errorDetails.setCellValue(teststepmodel.ErrorDetails);
                errorDetails.setCellStyle(rowCellStyle);

            }
            else
            {
            	 Cell errorDetails = row.createCell(9);
                 errorDetails.setCellValue("N\\A");
                 errorDetails.setCellStyle(getGenericCellStyleMiddle(workbook));           }
            
        }
        }
	}
	
	public void AddTestCaseDetails(Workbook workbook, Sheet sheet,CreationHelper createHelper,ArrayList<TestCaseResult> testCaseResults)
	{
        int rowNum = 1;
        for(TestCaseResult testCaseResult : testCaseResults) {
            Row row = sheet.createRow(rowNum++);

            row.createCell(0)
            .setCellValue(rowNum-1);

            Cell SNO = row.createCell(0);
            SNO.setCellValue(rowNum-1);
            SNO.setCellStyle(getGenericCellStyleMiddle(workbook));
            
     	   Cell TCName = row.createCell(1);
     	  TCName.setCellValue(testCaseResult.TestCaseName);
		try
		{
			TCName.setCellStyle(getHyperLinkCellStyle(workbook));
			Hyperlink link = createHelper.createHyperlink(HyperlinkType.DOCUMENT);
			link.setAddress("'" + testCaseResult.TestCaseName+"'!A1");
			TCName.setHyperlink(link);
			

		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			System.out.println(e.getStackTrace());
		}
		
		  Cell TCDesc = row.createCell(2);
		  TCDesc.setCellValue(testCaseResult.TestCaseDescription);
		  TCDesc.setCellStyle(getGenericCellStyle(workbook));
     	 

		  Cell Module = row.createCell(3);
		  Module.setCellValue(testCaseResult.Module);
		  Module.setCellStyle(getGenericCellStyleMiddle(workbook));
		  
		  
		  Cell TestCaseCategory = row.createCell(4);
		  TestCaseCategory.setCellValue(testCaseResult.TestCaseCategory);
		  TestCaseCategory.setCellStyle(getGenericCellStyleMiddle(workbook));
		  
		  Cell CaseNumber = row.createCell(5);
		  CaseNumber.setCellValue(testCaseResult.CaseNumber);
		  CaseNumber.setCellStyle(getGenericCellStyleMiddle(workbook));
		  
		  Cell ApplicationNumber = row.createCell(6);
		  ApplicationNumber.setCellValue(testCaseResult.ApplicationNumber);
		  ApplicationNumber.setCellStyle(getGenericCellStyleMiddle(workbook));

		  Cell Browser = row.createCell(7);
		  Browser.setCellValue(testCaseResult.Browser);
		  Browser.setCellStyle(getGenericCellStyleMiddle(workbook));

		  
	
            if(testCaseResult.TestCaseStatus.equalsIgnoreCase("PASS"))
            {
            	   Cell passStatus = row.createCell(8);
            	   passStatus.setCellValue(testCaseResult.TestCaseStatus);
            	   passStatus.setCellStyle(getPassCellStyle(workbook));
            	
            }

            else if(testCaseResult.TestCaseStatus.equalsIgnoreCase("FAIL"))
            {
            	   Cell failStatus = row.createCell(8);
            	   failStatus.setCellValue(testCaseResult.TestCaseStatus);
            	   failStatus.setCellStyle(getFailCellStyle(workbook));
            	
            }
            else
            {

      		  Cell TestCaseStatus = row.createCell(8);
      		TestCaseStatus.setCellValue(testCaseResult.TestCaseStatus);
      		TestCaseStatus.setCellStyle(getGenericCellStyleMiddle(workbook));

                

            }
            ReportCommon rcommon=new ReportCommon();
            
            Cell startTime = row.createCell(9);
            startTime.setCellValue(rcommon.ConvertLocalDateTimetoSQLDateTime(testCaseResult.StartTime));
            startTime.setCellStyle(getDateTimeCellStyle(workbook, createHelper));

            Cell endTime = row.createCell(10);
            endTime.setCellValue(rcommon.ConvertLocalDateTimetoSQLDateTime(testCaseResult.EndTime));
            endTime.setCellStyle(getDateTimeCellStyle(workbook, createHelper));
 

    		  Cell Duration = row.createCell(11);
    		  Duration.setCellValue(testCaseResult.Duration);
    		  Duration.setCellStyle(getGenericCellStyleMiddle(workbook));
    		  
    		
    		  
        
        }

	}

	public void AddTestModuleDetails(Workbook workbook, Sheet sheet,CreationHelper createHelper,ArrayList<ModuleResult> moduleResults)
	{
        int rowNum = 1;
        for(ModuleResult moduleResult : moduleResults) {
            Row row = sheet.createRow(rowNum++);
            
            ExcelRunSettings.DashboardRowCounter=rowNum;

            Cell SNo = row.createCell(0);
            SNo.setCellValue(rowNum-1);
            SNo.setCellStyle(getGenericCellStyleMiddle(workbook));
            

            Cell Module = row.createCell(1);
            Module.setCellValue(moduleResult.Module);
            Module.setCellStyle(getGenericCellStyleMiddle(workbook));
            

            Cell TCTotalCount = row.createCell(2);
            TCTotalCount.setCellValue(moduleResult.TCTotalCount);
            TCTotalCount.setCellStyle(getGenericCellStyleMiddle(workbook));

            

            Cell TCPassCount = row.createCell(3);
            TCPassCount.setCellValue(moduleResult.TCPassCount);
            TCPassCount.setCellStyle(getGenericCellStyleMiddle(workbook));

            

            Cell TCFailCount = row.createCell(4);
            TCFailCount.setCellValue(moduleResult.TCFailCount);
            TCFailCount.setCellStyle(getGenericCellStyleMiddle(workbook));
            
            

            Cell TCSkippedCount = row.createCell(5);
            TCSkippedCount.setCellValue(moduleResult.TCSkippedCount);
            TCSkippedCount.setCellStyle(getGenericCellStyleMiddle(workbook));

        }
	}

	public void AddTestBrowserDetails(Workbook workbook, Sheet sheet,CreationHelper createHelper,ArrayList<BrowserResult> browserResults)
	{
		ExcelRunSettings.DashboardRowCounter=ExcelRunSettings.DashboardRowCounter+1;
		int rowNum = ExcelRunSettings.DashboardRowCounter;
		int BrowserRowNo=1;
        for(BrowserResult browserResult : browserResults) {
            Row row = sheet.createRow(rowNum++);
            
       
            Cell SNo = row.createCell(0);
            SNo.setCellValue(BrowserRowNo++);
            SNo.setCellStyle(getGenericCellStyleMiddle(workbook));
            

            Cell Module = row.createCell(1);
            Module.setCellValue(browserResult.Browser);
            Module.setCellStyle(getGenericCellStyleMiddle(workbook));
            

            Cell TCTotalCount = row.createCell(2);
            TCTotalCount.setCellValue(browserResult.TCTotalCount);
            TCTotalCount.setCellStyle(getGenericCellStyleMiddle(workbook));

            

            Cell TCPassCount = row.createCell(3);
            TCPassCount.setCellValue(browserResult.TCPassCount);
            TCPassCount.setCellStyle(getGenericCellStyleMiddle(workbook));

            

            Cell TCFailCount = row.createCell(4);
            TCFailCount.setCellValue(browserResult.TCFailCount);
            TCFailCount.setCellStyle(getGenericCellStyleMiddle(workbook));
            
            

            Cell TCSkippedCount = row.createCell(5);
            TCSkippedCount.setCellValue(browserResult.TCSkippedCount);
            TCSkippedCount.setCellStyle(getGenericCellStyleMiddle(workbook));

        
        
        }

	}

	public CellStyle getDateCellStyle(Workbook workbook,CreationHelper createHelper)
	{
        CellStyle dateCellStyle = workbook.createCellStyle();
        dateCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("dd-MM-yyyy"));
        dateCellStyle.setBorderTop(BorderStyle.THICK);
        dateCellStyle.setBorderLeft(BorderStyle.THICK);
        dateCellStyle.setBorderRight(BorderStyle.THICK);
        dateCellStyle.setBorderBottom(BorderStyle.THICK);
        dateCellStyle.setAlignment(HorizontalAlignment.CENTER);
        return dateCellStyle;
	}

	
	
	public CellStyle getDateTimeCellStyle(Workbook workbook,CreationHelper createHelper)
	{
        CellStyle dateCellStyle = workbook.createCellStyle();
        dateCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("dd-MM-yyyy HH:MM:SS.SSS"));
        dateCellStyle.setBorderTop(BorderStyle.THICK);
        dateCellStyle.setBorderLeft(BorderStyle.THICK);
        dateCellStyle.setBorderRight(BorderStyle.THICK);
        dateCellStyle.setBorderBottom(BorderStyle.THICK);
        dateCellStyle.setAlignment(HorizontalAlignment.CENTER);
        return dateCellStyle;
	}

	public CellStyle getPassCellStyle(Workbook workbook)
	{
	     Font passFont = workbook.createFont();
	     passFont.setBold(false);
	     passFont.setFontHeightInPoints((short) 9);
	     passFont.setFontName("Verdana");
	     passFont.setColor(IndexedColors.DARK_GREEN.getIndex());

	        // Create a CellStyle with the font
	        CellStyle passCellStyle = workbook.createCellStyle();
	        passCellStyle.setFont(passFont);
	        passCellStyle.setFillForegroundColor(IndexedColors.LIGHT_GREEN.getIndex());
	        
	        passCellStyle.setFillBackgroundColor(IndexedColors.LIGHT_GREEN.getIndex());
	        passCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
	        passCellStyle.setAlignment(HorizontalAlignment.CENTER);
	        passCellStyle.setBorderTop(BorderStyle.THICK);
	        passCellStyle.setBorderLeft(BorderStyle.THICK);
	        passCellStyle.setBorderRight(BorderStyle.THICK);
	        passCellStyle.setBorderBottom(BorderStyle.THICK);
	        passCellStyle.setAlignment(HorizontalAlignment.CENTER);
	return passCellStyle;
	}

	public CellStyle getFailCellStyle(Workbook workbook)
	{
	     Font failFont = workbook.createFont();
	     failFont.setBold(false);
	     failFont.setFontHeightInPoints((short) 9);
	     failFont.setFontName("Verdana");
	     failFont.setColor(IndexedColors.DARK_RED.getIndex());

	        // Create a CellStyle with the font
	        CellStyle failCellStyle = workbook.createCellStyle();
	        failCellStyle.setFont(failFont);
	        failCellStyle.setFillBackgroundColor(IndexedColors.RED.getIndex());
	        failCellStyle.setFillForegroundColor(IndexedColors.RED.getIndex());
	        failCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

	        failCellStyle.setBorderTop(BorderStyle.THICK);
	        failCellStyle.setBorderLeft(BorderStyle.THICK);
	        failCellStyle.setBorderRight(BorderStyle.THICK);
	        failCellStyle.setBorderBottom(BorderStyle.THICK);
	        failCellStyle.setAlignment(HorizontalAlignment.CENTER);
	        return failCellStyle;
	}

	
	public CellStyle getHyperLinkCellStyle(Workbook workbook)
	{
	     Font hlink_font = workbook.createFont();
	     hlink_font.setBold(false);
	     hlink_font.setFontHeightInPoints((short) 9);
	     hlink_font.setFontName("Verdana");
	     hlink_font.setColor(IndexedColors.BLUE.getIndex());
	     
	     hlink_font.setUnderline(Font.U_SINGLE);

	        // Create a CellStyle with the font
	        CellStyle hlinkCellStyle = workbook.createCellStyle();
	        hlinkCellStyle.setFont(hlink_font);
	        hlinkCellStyle.setBorderTop(BorderStyle.THICK);
	        hlinkCellStyle.setBorderLeft(BorderStyle.THICK);
	        hlinkCellStyle.setBorderRight(BorderStyle.THICK);
	        hlinkCellStyle.setBorderBottom(BorderStyle.THICK);
	        hlinkCellStyle.setAlignment(HorizontalAlignment.CENTER);
	        return hlinkCellStyle;
	}

	
	public CellStyle getGenericCellStyle(Workbook workbook)
	{
		
        Font rowFont = workbook.createFont();
        rowFont.setBold(false);
        rowFont.setFontHeightInPoints((short) 9);
        rowFont.setFontName("Verdana");
        rowFont.setColor(IndexedColors.BLACK.getIndex());

        CellStyle rowCellStyle = workbook.createCellStyle();
        rowCellStyle.setFont(rowFont);
        rowCellStyle.setBorderTop(BorderStyle.THICK);
        rowCellStyle.setBorderLeft(BorderStyle.THICK);
        rowCellStyle.setBorderRight(BorderStyle.THICK);
        rowCellStyle.setBorderBottom(BorderStyle.THICK);
        rowCellStyle.setAlignment(HorizontalAlignment.LEFT);
        rowCellStyle.setWrapText(true);
		return rowCellStyle;
    

	}

	public CellStyle getGenericCellStyleMiddle(Workbook workbook)
	{
		
        Font rowFont = workbook.createFont();
        rowFont.setBold(false);
        rowFont.setFontHeightInPoints((short) 9);
        rowFont.setFontName("Verdana");
        rowFont.setColor(IndexedColors.BLACK.getIndex());

        CellStyle rowCellStyle = workbook.createCellStyle();
        rowCellStyle.setFont(rowFont);
        rowCellStyle.setBorderTop(BorderStyle.THICK);
        rowCellStyle.setBorderLeft(BorderStyle.THICK);
        rowCellStyle.setBorderRight(BorderStyle.THICK);
        rowCellStyle.setBorderBottom(BorderStyle.THICK);
        rowCellStyle.setWrapText(true);
        rowCellStyle.setAlignment(HorizontalAlignment.CENTER);
		return rowCellStyle;
    

	}

	
	public CellStyle getLeftBorderStyle(Workbook workbook)
	{
		
        Font rowFont = workbook.createFont();
        rowFont.setBold(false);
        rowFont.setFontHeightInPoints((short) 9);
        rowFont.setFontName("Verdana");
        rowFont.setColor(IndexedColors.BLACK.getIndex());

        CellStyle rowCellStyle = workbook.createCellStyle();
        rowCellStyle.setFillBackgroundColor(IndexedColors.GREY_40_PERCENT.getIndex());
        rowCellStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        rowCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

        rowCellStyle.setFont(rowFont);
        rowCellStyle.setBorderTop(BorderStyle.THICK);
        rowCellStyle.setBorderLeft(BorderStyle.THICK);
        rowCellStyle.setBorderRight(BorderStyle.NONE);
        rowCellStyle.setBorderBottom(BorderStyle.THICK);
        rowCellStyle.setWrapText(false);
        rowCellStyle.setAlignment(HorizontalAlignment.CENTER);
		return rowCellStyle;
    

	}

	
	public CellStyle getRightBorderStyle(Workbook workbook)
	{
		
        Font rowFont = workbook.createFont();
        rowFont.setBold(false);
        rowFont.setFontHeightInPoints((short) 9);
        rowFont.setFontName("Verdana");
        rowFont.setColor(IndexedColors.BLACK.getIndex());

        CellStyle rowCellStyle = workbook.createCellStyle();
        rowCellStyle.setFillBackgroundColor(IndexedColors.GREY_40_PERCENT.getIndex());
        rowCellStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        rowCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

        rowCellStyle.setFont(rowFont);
        rowCellStyle.setBorderTop(BorderStyle.THICK);
        rowCellStyle.setBorderLeft(BorderStyle.NONE);
        rowCellStyle.setBorderRight(BorderStyle.THICK);
        rowCellStyle.setBorderBottom(BorderStyle.THICK);
        rowCellStyle.setWrapText(false);
        rowCellStyle.setAlignment(HorizontalAlignment.CENTER);
		return rowCellStyle;
  

	}

	
	
	public CellStyle getNoSideBorderStyle(Workbook workbook)
	{
		
        Font rowFont = workbook.createFont();
        rowFont.setBold(true);
        rowFont.setFontHeightInPoints((short) 9);
        rowFont.setFontName("Verdana");
        rowFont.setColor(IndexedColors.BLACK.getIndex());

        
        CellStyle rowCellStyle = workbook.createCellStyle();
        rowCellStyle.setFillBackgroundColor(IndexedColors.GREY_40_PERCENT.getIndex());
        rowCellStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        rowCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

        rowCellStyle.setFont(rowFont);
        rowCellStyle.setBorderTop(BorderStyle.THICK);
        rowCellStyle.setBorderLeft(BorderStyle.NONE);
        rowCellStyle.setBorderRight(BorderStyle.NONE);
        rowCellStyle.setBorderBottom(BorderStyle.THICK);
        rowCellStyle.setWrapText(false);
        rowCellStyle.setAlignment(HorizontalAlignment.CENTER);
		return rowCellStyle;
  

	}

	public CellStyle getHeaderCellStyle(Workbook workbook)
	{
		try {
	     Font headerFont = workbook.createFont();
	        headerFont.setBold(true);
	        headerFont.setFontHeightInPoints((short) 9);
	        headerFont.setFontName("Verdana");
	        headerFont.setColor(IndexedColors.BLACK.getIndex());

	        // Create a CellStyle with the font
	        CellStyle headerCellStyle = workbook.createCellStyle();
	        headerCellStyle.setFont(headerFont);
	        headerCellStyle.setFillBackgroundColor(IndexedColors.GREY_40_PERCENT.getIndex());
	        headerCellStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
	        headerCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
	        headerCellStyle.setBorderTop(BorderStyle.THICK);
	        headerCellStyle.setBorderLeft(BorderStyle.THICK);
	        headerCellStyle.setBorderRight(BorderStyle.THICK);
	        headerCellStyle.setBorderBottom(BorderStyle.THICK);
	        headerCellStyle.setAlignment(HorizontalAlignment.CENTER);

	        return headerCellStyle;
		}
		catch(Exception e) 
		{
			System.out.println(e.getMessage());
			System.out.println(e.getStackTrace());
			throw e;
		}
	        

	}
	public Hyperlink getHyperLinkSheet(Workbook workbook,CreationHelper createHelper,String SheetName)
	{
		Hyperlink link = createHelper.createHyperlink(HyperlinkType.DOCUMENT);
		link.setAddress("'" + SheetName+"'!A1");
		return link;
	}

	

	public Hyperlink getHyperLinkScreenshot(Workbook workbook,CreationHelper createHelper,String Path)
	{
		Hyperlink link = createHelper.createHyperlink(HyperlinkType.FILE);
		Path= Path.replace("\\", "/");
		//Path= Path.replace(" ", "_");
		System.out.println(Path);
		link.setAddress(Path);
		return link;
	}

	
	public void closeWorkBook(Workbook workbook, String FilePath) throws Exception
	{
		try 
		{
			FileOutputStream fileOut = new FileOutputStream(FilePath);
	        workbook.write(fileOut);
	        fileOut.close();
	        workbook.close();
		}
		catch(Exception e) 
		{
			System.out.println(e.getStackTrace());
			System.out.println(e.getMessage());
			throw e;
			
		}
        
	}
	
}
