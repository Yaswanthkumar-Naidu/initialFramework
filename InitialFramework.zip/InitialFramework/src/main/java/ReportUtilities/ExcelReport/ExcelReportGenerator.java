package ReportUtilities.ExcelReport;

import ReportUtilities.Constants.ReportContants;
import ReportUtilities.Model.ExtentModel.TestCaseDetails;
import ReportUtilities.Model.ExtentModel.TestStepDetails;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.UUID;

public class ExcelReportGenerator {

	
	ArrayList<String> BrowserHeader = new ArrayList<String>();
	ArrayList<String> ModuleHeader = new ArrayList<String>();
	ArrayList<String> TestCaseHeader = new ArrayList<String>();
	ArrayList<String> TestStepHeader = new ArrayList<String>();
	ArrayList<Integer> BrowserHeaderSize = new ArrayList<Integer>();
	ArrayList<Integer> ModuleHeaderSize = new ArrayList<Integer>();
	ArrayList<Integer> TestCaseHeaderSize = new ArrayList<Integer>();
	ArrayList<Integer> TestStepHeaderSize = new ArrayList<Integer>();

	
	public void InitializeColumnHeaders()
	{
		BrowserHeader.add("S.No");
		BrowserHeaderSize.add(10*250);
		BrowserHeader.add("Browser");
		BrowserHeaderSize.add(20*250);
		BrowserHeader.add("TotalTestCases");
		BrowserHeaderSize.add(20*250);
		BrowserHeader.add("TestCasesPassed");
		BrowserHeaderSize.add(20*250);
		BrowserHeader.add("TestCasesFailed");
		BrowserHeaderSize.add(20*250);
		BrowserHeader.add("TestCasesSkipped");
		BrowserHeaderSize.add(20*250);
		
		ModuleHeader.add("S.No");
		ModuleHeaderSize.add(10*250);
		ModuleHeader.add("Module");
		ModuleHeaderSize.add(20*250);
		ModuleHeader.add("TotalTestCases");
		ModuleHeaderSize.add(20*250);
		ModuleHeader.add("TestCasesPassed");
		ModuleHeaderSize.add(20*250);
		ModuleHeader.add("TestCasesFailed");
		ModuleHeaderSize.add(20*250);
		ModuleHeader.add("TestCasesSkipped");
		ModuleHeaderSize.add(20*250);
		
		TestCaseHeader.add("S.No");
		TestCaseHeaderSize.add(10*250);
		TestCaseHeader.add("TestCaseName");
		TestCaseHeaderSize.add(20*250);
		TestCaseHeader.add("TestCaseDetails");
		TestCaseHeaderSize.add(40*250);
		TestCaseHeader.add("Module");
		TestCaseHeaderSize.add(15*250);
		TestCaseHeader.add("TestCaseCategory");
		TestCaseHeaderSize.add(25*250);
		TestCaseHeader.add("CaseNumber");
		TestCaseHeaderSize.add(25*250);
		TestCaseHeader.add("ApplicationNumber");
		TestCaseHeaderSize.add(25*250);
		TestCaseHeader.add("Browser");
		TestCaseHeaderSize.add(15*250);
		TestCaseHeader.add("Status");
		TestCaseHeaderSize.add(15*250);
		TestCaseHeader.add("StartTime");
		TestCaseHeaderSize.add(25*250);
		TestCaseHeader.add("EndTime");
		TestCaseHeaderSize.add(25*250);
		TestCaseHeader.add("Duration");
		TestCaseHeaderSize.add(15*250);
		
		
		TestStepHeader.add("S.No");
		TestStepHeaderSize.add(10*250);
		TestStepHeader.add("TestStepName");
		TestStepHeaderSize.add(25*250);
		TestStepHeader.add("TestStepDetails");
		TestStepHeaderSize.add(40*250);
		TestStepHeader.add("Status");
		TestStepHeaderSize.add(15*250);
		TestStepHeader.add("StartTime");
		TestStepHeaderSize.add(25*250);
		TestStepHeader.add("EndTime");
		TestStepHeaderSize.add(25*250);
		TestStepHeader.add("Duration");
		TestStepHeaderSize.add(15*250);
		TestStepHeader.add("Screenshot");
		TestStepHeaderSize.add(15*250);
		TestStepHeader.add("ErrorMessage");
		TestStepHeaderSize.add(25*250);
		TestStepHeader.add("ErrorDetails");
		TestStepHeaderSize.add(40*250);
		
		
	}
	
	public void GenerateExcelReport(ArrayList<HashMap<UUID, TestCaseDetails>> TestCaseRepository,String FilePath) throws Exception
	{
		try {
		InitializeColumnHeaders();
		
		ExcelReportCommon excelreport = new ExcelReportCommon();
		
		Workbook workbook=excelreport.createWorkbook();
		
		CreationHelper createHelper= excelreport.createExcelHelper(workbook);
		
		Sheet DashboardSheet= excelreport.createSheet(workbook, "Dashboard");
	
		excelreport.createHeader(workbook, DashboardSheet, ModuleHeader,ModuleHeaderSize,0);	
	
		excelreport.AddTestModuleDetails(workbook, DashboardSheet, createHelper,ReportContants.moduleResults);

		ExcelRunSettings.DashboardRowCounter=ExcelRunSettings.DashboardRowCounter+2;
		
		excelreport.createHeader(workbook, DashboardSheet, BrowserHeader,BrowserHeaderSize,ExcelRunSettings.DashboardRowCounter);	
		
		excelreport.AddTestBrowserDetails(workbook, DashboardSheet, createHelper,ReportContants.browserResults);
	
		
		Sheet TestCaseDetails= excelreport.createSheet(workbook, "TestCases");

		for (HashMap<UUID,TestCaseDetails> DictTC : TestCaseRepository)
		{
			TestCaseDetails testCaseDetails = DictTC.values().stream().findFirst().get();
			String TestCaseName = testCaseDetails.TestCaseName;

			Sheet TestStepDetails= excelreport.createSheet(workbook, TestCaseName);
			ExcelRunSettings.TCSheetMapping.put(TestCaseName,  TestStepDetails);
		}
		excelreport.createHeader(workbook, TestCaseDetails, TestCaseHeader,TestCaseHeaderSize,0);
	
		excelreport.AddTestCaseDetails(workbook, TestCaseDetails, createHelper,ReportContants.testcaseResults);

		if (TestCaseRepository != null)
		{

			for (HashMap<UUID,TestCaseDetails> DictTC : TestCaseRepository)
			{
				TestCaseDetails testCaseDetails = DictTC.values().stream().findFirst().get();
				String TestCaseName = testCaseDetails.TestCaseName;

				//Sheet TestStepDetails= excelreport.createSheet(workbook, TestCaseName);
				
				Sheet TestStepDetails= ExcelRunSettings.TCSheetMapping.get(TestCaseName);
				excelreport.createHeader(workbook, TestStepDetails, TestStepHeader,TestStepHeaderSize,0);

				ArrayList<TestStepDetails> testStepDetails = testCaseDetails.stepDetails;
				
				excelreport.AddTestStepDetails(workbook, TestStepDetails, createHelper, testStepDetails);


			}
		}
		
		excelreport.closeWorkBook(workbook, FilePath);

		}
		catch(Exception e) 
		{
			System.out.println(e.getStackTrace());
			System.out.println(e.getMessage());
			throw e;
		}
		
	}
	
	public void GenerateExcelReportTestCase(TestCaseDetails testCaseDetails,String FilePath) throws Exception
	{
		InitializeColumnHeaders();
		
		ExcelReportCommon excelreport = new ExcelReportCommon();
		
		Workbook workbook=excelreport.createWorkbook();
		
		CreationHelper createHelper= excelreport.createExcelHelper(workbook);
		

				String TestCaseName = testCaseDetails.TestCaseName;

				Sheet TestStepDetails= excelreport.createSheet(workbook, TestCaseName);
				

				excelreport.createHeader(workbook, TestStepDetails, TestStepHeader,TestStepHeaderSize,0);

				ArrayList<TestStepDetails> testStepDetails = testCaseDetails.stepDetails;
				
				excelreport.AddTestStepDetails(workbook, TestStepDetails, createHelper, testStepDetails);


		excelreport.closeWorkBook(workbook, FilePath);

		
		
	}
}
