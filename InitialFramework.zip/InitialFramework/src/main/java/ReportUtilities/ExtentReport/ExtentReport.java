package ReportUtilities.ExtentReport;

import ReportUtilities.Model.ExtentModel.TestCaseDetails;
import ReportUtilities.Model.ExtentModel.TestStepDetails;
import ReportUtilities.Model.InterfaceTCDetails;
import ReportUtilities.Model.InterfaceTestRun;
import ReportUtilities.Model.TestCaseParam;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.CodeLanguage;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.model.ExceptionInfo;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.UUID;

public class ExtentReport
{

	public static ExtentHtmlReporter htmlReporter;
	public static ExtentReports extent;

	public static HashMap<Integer, ExtentTest> DictExtentTestScenario = new HashMap<Integer, ExtentTest>();
	public static HashMap<Integer, String> DictExtentTestCase = new HashMap<Integer, String>();
	public static HashMap<Integer, ArrayList<ExtentTestSteps>> DictExtentTestSteps = new HashMap<Integer, ArrayList<ExtentTestSteps>>();

//added for live report
	public static HashMap<String, ExtentTest> TCExtentMapping = new HashMap<String, ExtentTest>();	
	public void StartReport(String ReportPath, String HostName, String Environment, String Username)
	{
		try
		{
			ReportPath = ReportPath + "/ExtentReport_RunTime.html";
	
	
			
			htmlReporter = new ExtentHtmlReporter(ReportPath);
			extent = new ExtentReports();
			extent.attachReporter(htmlReporter);
			extent.setSystemInfo("Host Name", HostName);
			extent.setSystemInfo("Environment", Environment);
			extent.setSystemInfo("Username", Username);
		}
		catch(Exception e)
		{
			System.out.println("Unable to initialize the Extent Report");
			System.out.println(e.getStackTrace());
			System.out.println(e.getMessage());
			
			
			
		}
		
		
		}
	
	public void StartReport(String ReportPath, String Environment)
	{
		try
		{
			ReportPath = ReportPath + "/ExtentReport_RunTime.html";
	
	
			
			htmlReporter = new ExtentHtmlReporter(ReportPath);
			extent = new ExtentReports();
			extent.attachReporter(htmlReporter);
			extent.setSystemInfo("Environment", Environment);
		}
		catch(Exception e)
		{
			System.out.println("Unable to initialize the Extent Report");
			System.out.println(e.getStackTrace());
			System.out.println(e.getMessage());
			
			
			
		}
		
		
		}
	public void StartTest(String TestCase,String ModuleName, String Browser, String TestCaseDescription)
	{
		try
		{
		
		//extent = new ExtentReports();
		ExtentTest TC = extent.createTest(TestCase, TestCaseDescription);
		ExtentTest test =TC.createNode("Iteration==>1");
		test.assignCategory(Browser);
		test.assignCategory(ModuleName);
		Thread.sleep(0);
		TCExtentMapping.put(TestCase+"_"+ ModuleName+ "_" + Browser, test);

		}
	catch(Exception e)
	{
		System.out.println("Unable to initialize the Extent Test Case ==>"+TestCase );
		System.out.println(e.getStackTrace());
		System.out.println(e.getMessage());
		
		
		
	}

	
	}


	
	public void StartTest(String TestCase,String ModuleName, String Browser, int Iteration,String TestCaseDescription)
	{
		
		try
		{
		ExtentTest test;
		
		if(Iteration>1)
		{
			ExtentTest TC =TCExtentMapping.get(TestCase+"_"+ ModuleName+ "_" + Browser);
		
            test =TC.createNode("Iteration==>"+Iteration);
            TCExtentMapping.put(TestCase+"_"+ ModuleName+ "_" + Browser, test);
		}
		else
		{
			ExtentTest TC = extent.createTest(TestCase, TestCaseDescription);
		    test =TC.createNode("Iteration==>1");	
		
			test.assignCategory(Browser);
			test.assignCategory(ModuleName);
	
		}
		
		TCExtentMapping.put(TestCase+"_"+ ModuleName+ "_" + Browser, test);
		}
		catch(Exception e)
		{
			System.out.println("Unable to initialize the Extent Test Case ==>"+TestCase );
			System.out.println(e.getStackTrace());
			System.out.println(e.getMessage());
			
			
			
		}

	}
	
	public void addTestStepsLogs(TestCaseParam testCaseParam, TestStepDetails TSDetails)
	{

		String BusinessArea="";
		String ScreenName="";
		try
		{
		ExtentTest test=TCExtentMapping.get(testCaseParam.TestCaseName  +"_"+ testCaseParam.ModuleName + "_" + testCaseParam.Browser);
		

		
		if((TSDetails.testStepType==TestStepDetails.TestStepType.TestStep)||
				(TSDetails.testStepType==TestStepDetails.TestStepType.Verification)||
				(TSDetails.testStepType==TestStepDetails.TestStepType.Exception))
		{	
			if (TSDetails.ScreenShotData.equals(""))
			{
				test.log(TSDetails.ExtentStatus, TSDetails.StepName);
				
			}
			else
			{
				test.log(TSDetails.ExtentStatus,WriteImageToReport(TSDetails.ScreenShotData, TSDetails.StepName));
			}
		}
		
		if(TSDetails.testStepType==TestStepDetails.TestStepType.Module)
		{
				test.log(Status.INFO, "=================Module: " + TSDetails.ModuleName + "==============");
		}
		
		if(TSDetails.testStepType==TestStepDetails.TestStepType.Screen)
		{
				test.log(Status.INFO, "=================Screen: " + TSDetails.ScreenName + "==============");
		}
		
		if(TSDetails.testStepType==TestStepDetails.TestStepType.Module_Screen)
		{
				test.log(Status.INFO, "=================Module: " + TSDetails.ModuleName + "==============");
				test.log(Status.INFO, "=================Screen: " + TSDetails.ScreenName + "==============");
		}
		
		

		}
		catch(Exception e)
		{
			System.out.println("Unable to update the Extent Test Step ==>"+TSDetails.StepName );
			System.out.println(e.getStackTrace());
			System.out.println(e.getMessage());
			
			
			
		}



	}

	//live report end


	public void StartReport(String reportPath, String HostName, String Environment, String Username, int... node)
	{
		if(node==null)
			node[0]=0;
		reportPath = reportPath + "../TestReports/ExtentReport.html";
		htmlReporter = new ExtentHtmlReporter(reportPath);
		extent = new ExtentReports();
		extent.attachReporter(htmlReporter);
		extent.setSystemInfo("Host Name", HostName);
		extent.setSystemInfo("Environment", Environment);
		extent.setSystemInfo("Username", Username);
	}


	public void StartTest(String TestScenarioName, String TestScenarioDescription, int... node)
	{
		if(node==null)
			node[0]=0;
		ExtentTest test = extent.createTest(TestScenarioName, TestScenarioDescription);
		//if (DictExtentTestScenario.ContainsKey(node))
		//{
		//    DictExtentTestScenario[node] = test;
		//}
		//else
		//{
		//    DictExtentTestScenario.Add(node, test);
		//}
	}

	public void EndTest(String TestCaseName, String TestCaseDesc, String ModuleName, int... node)
	{
		if(node==null)
			node[0]=0;
		int FailCounter = 0;

		if (DictExtentTestScenario.containsKey(node))
		{
			ExtentTest TestScenario = DictExtentTestScenario.get(node[0]);
			ExtentTest  ExtentNode = TestScenario.createNode(TestCaseName, TestCaseDesc);

			ArrayList<ExtentTestSteps> ArrayListTestSteps = DictExtentTestSteps.get(node[0]);

			for (ExtentTestSteps ETS : ArrayListTestSteps)
			{
				if (ETS.TestStepStatus == ExtentConstants.TestStepStatus.PASS)
				{
					ExtentNode.createNode(ETS.TestStepName, ETS.TestStepDesc).pass(ETS.TestStepName + "--Passed");
				}

				else if (ETS.TestStepStatus == ExtentConstants.TestStepStatus.FAIL)
				{
					ExtentNode.createNode(ETS.TestStepName, ETS.TestStepDesc).fail(ETS.TestStepName + "--Failed");
					FailCounter++;
				}

				else
				{
					ExtentNode.createNode(ETS.TestStepName, ETS.TestStepDesc).skip(ETS.TestStepName + "--Skipped");
				}
			}

			if (FailCounter > 0)
			{
				ExtentNode.fail(TestCaseName + "--Fail");
			}
			else
			{
				ExtentNode.pass(TestCaseName + "--Pass");
			}


			ExtentNode.assignCategory(ModuleName);

			if (node[0] > 0)
			{
				ExtentNode.assignDevice("Node -- " + node[0]);
			}

		}
	}
	
	
	
	public void EndReport()

	{

		//End Report

		extent.flush();

	}

	public void addTestStepsLogs(String TestStepName, String TestStepDesc, ExtentConstants.TestStepStatus testStepStatus, int... node)
	{
		if(node==null)
			node[0]=0;

		
		ExtentTestSteps extentTestSteps = new ExtentTestSteps();
		if (DictExtentTestSteps.containsKey(node))
		{
			ArrayList<ExtentTestSteps> ArrayListTestSteps = DictExtentTestSteps.get(node);
			extentTestSteps.TestStepName = TestStepName;
			extentTestSteps.TestStepDesc = TestStepDesc;
			extentTestSteps.TestStepStatus = testStepStatus;

			ArrayListTestSteps.add(extentTestSteps);
			DictExtentTestSteps.putIfAbsent( node[0] , ArrayListTestSteps);
		}
		else
		{
			ArrayList<ExtentTestSteps> ArrayListTestSteps = new ArrayList<ExtentTestSteps>();
			extentTestSteps.TestStepName = TestStepName;
			extentTestSteps.TestStepDesc = TestStepDesc;
			extentTestSteps.TestStepStatus = testStepStatus;

			ArrayListTestSteps.add(extentTestSteps);
			DictExtentTestSteps.putIfAbsent(node[0], ArrayListTestSteps);
		}

	}

	public void CreateExtentReportFromModel(String ReportPath, InterfaceTestRun model,
		String TestName,String Environment,String ExecutedBy, String RequestPath,
		String ResponsePath,boolean ShareAttachmentForPassedTestCases)
	{

		ReportPath = ReportPath + "/ExtentReport_Interface.html";
		ExtentHtmlReporter htmlReporter_lcl = new ExtentHtmlReporter(ReportPath);
		ExtentReports extent_lcl = new ExtentReports();
		extent_lcl.attachReporter(htmlReporter_lcl);
		extent_lcl.setSystemInfo("Host Name", TestName);
		extent_lcl.setSystemInfo("Environment", Environment);
		extent_lcl.setSystemInfo("Username", ExecutedBy);

		if (model != null)
		{
			for (InterfaceTCDetails node : model.interfaceTCDetails )
			{
				String TestCaseName = "";
				String RequestFileName = "";
				String ResponseFileName = "";
				if (node.Iteration > 1)
				{
					TestCaseName = node.Module + "==>" + node.InterfaceName + "==> Iteration: " + node.Iteration;
					RequestFileName="Request_"+ node.Module + "_" + node.InterfaceName + "_" + node.Iteration;
					ResponseFileName = "Response_" + node.Module + "_" + node.InterfaceName + "_" + node.Iteration;
				}
				else
				{
					TestCaseName = node.Module + "==>" + node.InterfaceName;
					RequestFileName = "Request_" + node.Module + "_" + node.InterfaceName;
					ResponseFileName = "Response_" + node.Module + "_" + node.InterfaceName;
				}

				ExtentTest test = extent_lcl.createTest(node.Module+"==>"+ node.InterfaceName);

				test.assignCategory(node.Module);
				if (node.TestCaseStatus == ExtentConstants.TestStepStatus.FAIL)
				{
					test.log(Status.FAIL, TestCaseName);
					test.log(Status.INFO, WriteDataToTextFile(RequestPath, RequestFileName,node.RequestData,node.FileFormat));
					test.log(Status.INFO, WriteDataToTextFile(ResponsePath, ResponseFileName, node.ResponseData, node.FileFormat));
					test.log(Status.ERROR, node.ErrorMessage);
				}
				else if (node.TestCaseStatus == ExtentConstants.TestStepStatus.PASS)
				{
					test.log(Status.PASS, TestCaseName);
					if (ShareAttachmentForPassedTestCases)
					{
						test.log(Status.INFO, WriteDataToTextFile(RequestPath, RequestFileName, node.RequestData, node.FileFormat));
						test.log(Status.INFO, WriteDataToTextFile(ResponsePath, ResponseFileName, node.ResponseData, node.FileFormat));
						test.log(Status.PASS, node.ErrorMessage);
					}
				}
				else 
				{
					test.log(Status.SKIP, TestCaseName);

				}
			}
		}
		extent_lcl.flush();
	}



	public void CreateExtentReport_Category(String ReportPath, ArrayList<HashMap<UUID, TestCaseDetails>> TestCaseRepository,
	String TestName, String Environment, String ExecutedBy) throws Exception
	{
		
		try
		{

			ReportPath = ReportPath + "/TestResults_Category.html";
			

		ExtentHtmlReporter htmlReporter_lcl = new ExtentHtmlReporter(ReportPath);
		ExtentReports extent_lcl = new ExtentReports();
		try
		{
			extent_lcl.attachReporter(htmlReporter_lcl);
		
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			System.out.println(e.getStackTrace());
			throw e;	
		}
		extent_lcl.setSystemInfo("Host Name", TestName);
		extent_lcl.setSystemInfo("Environment", Environment);
		extent_lcl.setSystemInfo("Username", ExecutedBy);

		if (TestCaseRepository != null)
		{

			for (HashMap<UUID,TestCaseDetails> DictTC : TestCaseRepository)
			{
				TestCaseDetails testCaseDetails = DictTC.values().stream().findFirst().get();
				String TestCaseName = testCaseDetails.TestCaseName;
				String TestCaseDescription = testCaseDetails.TestCaseDescription;
				String ModuleName = testCaseDetails.Module;
				String Browser = testCaseDetails.Browser;

				ExtentTest test = extent_lcl.createTest(TestCaseName);

				test.assignCategory(ModuleName);
				test.assignCategory(Browser);

				ArrayList<TestStepDetails> testStepDetails = testCaseDetails.stepDetails;
				ExtentTest MultiTCNode = null;
				ExtentTest ModuleNode = null;
				ExtentTest ScreenNode = null;
				ExtentTest ParentNode=null;

				String BusinessArea="";
				String ScreenName="";

				for (TestStepDetails TS : testStepDetails)
				{
					
					if(TS.testStepType==TestStepDetails.TestStepType.MultiTC)
					{
						
						MultiTCNode=test.createNode(TS.StepName);	
						ParentNode=MultiTCNode;
					}
					
					if(TS.testStepType==TestStepDetails.TestStepType.Module)
					{
						if(MultiTCNode==null)
						{
							if(BusinessArea.equals(TS.ModuleName)==false)
							{
								ModuleNode=test.createNode(TS.ModuleName);
								BusinessArea=TS.ModuleName;		
							}
						}
						else
						{
							if(BusinessArea.equals(TS.ModuleName)==false)
							{
							
							ModuleNode=MultiTCNode.createNode(TS.ModuleName);	
							BusinessArea=TS.ModuleName;
							}
						}
						
						ParentNode=ModuleNode;
					}
					else if(TS.testStepType==TestStepDetails.TestStepType.Screen)
					{
						if(ModuleNode==null)
						{
							if(ScreenName.equals(TS.ScreenName)==false)
							{

								ScreenNode=test.createNode(TS.ScreenName);	
								ScreenName=TS.ScreenName;

							}
						}
						else
						{
							if(ScreenName.equals(TS.ScreenName)==false)
							{
							ScreenNode=ModuleNode.createNode(TS.ScreenName);
							ScreenName=TS.ScreenName;
							}
						}
						
						ParentNode=ScreenNode;
					}
					else if(TS.testStepType==TestStepDetails.TestStepType.Module_Screen)
					{
						if(MultiTCNode==null)
						{
						
							if(BusinessArea.equals(TS.ModuleName)==false)
							{
								ModuleNode=test.createNode(TS.ModuleName);	
								BusinessArea=TS.ModuleName;
							}
							
							if(ScreenName.equals(TS.ScreenName)==false)
							{
								ScreenNode=ModuleNode.createNode(TS.ScreenName);						
								ScreenName=TS.ScreenName;
							}

	

						}
						else
						{
							if(BusinessArea.equals(TS.ModuleName)==false)
							{
						ModuleNode=MultiTCNode.createNode(TS.ModuleName);
						BusinessArea=TS.ModuleName;
							}
							
							if(ScreenName.equals(TS.ScreenName)==false)
							{
								ScreenNode=MultiTCNode.createNode(TS.ScreenName);
								ScreenName=TS.ScreenName;
							}
						}
						
						ParentNode=ScreenNode;
					}
					
					if(MultiTCNode==null &&ModuleNode==null && ScreenNode==null )
					{

					ParentNode=test;

					}
					
					if(TS.testStepType==TestStepDetails.TestStepType.TestStep)
					{
						if(TS.testStepFormat==TestStepDetails.TestStepFormat.Plain)
						{
	
							if (TS.ScreenShotData.equals(""))
							{
								ParentNode.log(TS.ExtentStatus, TS.StepName);
							}
							else
							{
								ParentNode.log(TS.ExtentStatus,WriteImageToReport(TS.ScreenShotData, TS.StepName));
							}		
						}
						else if(TS.testStepFormat==TestStepDetails.TestStepFormat.HTML)
						{
							
							ParentNode.log(TS.ExtentStatus ,MarkupHelper.createCodeBlock(TS.StepDescription));
						}
						
						else if(TS.testStepFormat==TestStepDetails.TestStepFormat.XML)
						{
							
							ParentNode.log(TS.ExtentStatus ,MarkupHelper.createCodeBlock(TS.StepDescription, CodeLanguage.XML));
						}
						else if(TS.testStepFormat==TestStepDetails.TestStepFormat.JSON)
						{
							
							ParentNode.log(TS.ExtentStatus ,MarkupHelper.createCodeBlock(TS.StepDescription, CodeLanguage.JSON));
						}
						else if(TS.testStepFormat==TestStepDetails.TestStepFormat.Code)
						{
							
							ParentNode.log(TS.ExtentStatus ,MarkupHelper.createCodeBlock(TS.StepDescription));
						}
//						else if(TS.testStepFormat==TestStepDetails.TestStepFormat.Table)
//						{
//							
//							ParentNode.log(TS.ExtentStatus ,MarkupHelper.createTable(TS.StepTableData));
//						}
						
					}
					else if(TS.testStepType==TestStepDetails.TestStepType.Verification)
					{
						
						
						if(TS.testStepFormat==TestStepDetails.TestStepFormat.XML)
						{

							ParentNode.log(TS.ExtentStatus ,TS.StepName);
							ExtentTest XMLChild = ParentNode.createNode(TS.StepName);
							XMLChild.info(MarkupHelper.createCodeBlock(TS.ExpectedResponse, CodeLanguage.XML));
							XMLChild.log(TS.ExtentStatus, MarkupHelper.createCodeBlock(TS.ActualResponse, CodeLanguage.XML));
						}
						else if(TS.testStepFormat==TestStepDetails.TestStepFormat.JSON)
						{
							
							ParentNode.log(TS.ExtentStatus ,TS.StepName);
							ExtentTest XMLChild = ParentNode.createNode(TS.StepName);
							XMLChild.info(MarkupHelper.createCodeBlock(TS.ExpectedResponse, CodeLanguage.JSON));
							XMLChild.log(TS.ExtentStatus, MarkupHelper.createCodeBlock(TS.ActualResponse, CodeLanguage.JSON));
						}
//						else if(TS.testStepFormat==TestStepDetails.TestStepFormat.Table)
//						{
//							
//							ParentNode.log(TS.ExtentStatus ,TS.StepName);
//							ExtentTest XMLChild = ParentNode.createNode(TS.StepName);
//							XMLChild.info(MarkupHelper.createTable(TS.ExpectedTableData));
//							XMLChild.log(TS.ExtentStatus, MarkupHelper.createTable(TS.ActualTableData));
//						}
						else
						{
							if(TS.ExtentStatus== Status.PASS)
							{
								ParentNode.pass(MarkupHelper.createLabel( " Expected : " + TS.ExpectedResponse+ "\n   ==> Actual : " + TS.ActualResponse , ExtentColor.GREEN));
							}
							else
							{
								ParentNode.fail(MarkupHelper.createLabel( " Expected : " + TS.ExpectedResponse+ "   \n ==> Actual : " + TS.ActualResponse , ExtentColor.RED));
							}
						}
					}
					else if(TS.testStepType==TestStepDetails.TestStepType.Exception)
					{
						ExceptionInfo EI = new ExceptionInfo();
						EI.setExceptionName(TS.ErrorMessage);
						EI.setStackTrace(TS.ErrorDetails);
						ParentNode.log(TS.ExtentStatus, EI);
						ParentNode.log(TS.ExtentStatus,WriteImageToReport(TS.ScreenShotData, TS.StepName));
					}
					
				}


			}
		}
		extent_lcl.flush();


		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			System.out.println(e.getStackTrace());
			throw e;	
		}
	}

	
	
	public void CreateExtentReport_Model(String ReportPath, ArrayList<HashMap<UUID, TestCaseDetails>> TestCaseRepository,
	String TestName, String Environment, String ExecutedBy) throws Exception
	{
		
		try
		{

			ReportPath = ReportPath + "/TestResults.html";
			

		ExtentHtmlReporter htmlReporter_lcl = new ExtentHtmlReporter(ReportPath);
		ExtentReports extent_lcl = new ExtentReports();
		try
		{
			extent_lcl.attachReporter(htmlReporter_lcl);
		
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			System.out.println(e.getStackTrace());
			throw e;	
		}
		extent_lcl.setSystemInfo("Host Name", TestName);
		extent_lcl.setSystemInfo("Environment", Environment);
		extent_lcl.setSystemInfo("Username", ExecutedBy);

		if (TestCaseRepository != null)
		{

			for (HashMap<UUID,TestCaseDetails> DictTC : TestCaseRepository)
			{
				TestCaseDetails testCaseDetails = DictTC.values().stream().findFirst().get();
				String TestCaseName = testCaseDetails.TestCaseName;
				String TestCaseDescription = testCaseDetails.TestCaseDescription;
				String ModuleName = testCaseDetails.Module;
				String Browser = testCaseDetails.Browser;

				ExtentTest test = extent_lcl.createTest(TestCaseName);

				test.assignCategory(ModuleName);
				test.assignCategory(Browser);

				ArrayList<TestStepDetails> testStepDetails = testCaseDetails.stepDetails;

				String BusinessArea="";
				String ScreenName="";
				for (TestStepDetails TS : testStepDetails)
				{
					if((TS.testStepType==TestStepDetails.TestStepType.TestStep)||
							(TS.testStepType==TestStepDetails.TestStepType.Verification)||
							(TS.testStepType==TestStepDetails.TestStepType.Exception))
					{	
						if (TS.ScreenShotData.equals(""))
						{
							test.log(TS.ExtentStatus, TS.StepName);
							
//							if((TS.testStepFormat==TestStepDetails.TestStepFormat.Table)
//									&& (TS.testStepType==TestStepDetails.TestStepType.TestStep))
//							{
//								test.info(MarkupHelper.createTable(TS.StepTableData));	
//							}
						}
						else
						{
							test.log(TS.ExtentStatus,WriteImageToReport(TS.ScreenShotData, TS.StepName));
						}
					}
					
					if(TS.testStepType==TestStepDetails.TestStepType.Module)
					{
						if(BusinessArea.equals(TS.ModuleName)==false)
						{
							BusinessArea=TS.ModuleName;
							test.log(Status.INFO, "=================Module: " + BusinessArea + "==============");
						}
					}
					
					if(TS.testStepType==TestStepDetails.TestStepType.Screen)
					{
						if(ScreenName.equals(TS.ScreenName)==false)
						{
							ScreenName=TS.ScreenName;
							test.log(Status.INFO, "=================Screen: " + ScreenName + "==============");
						}
					}
					
					if(TS.testStepType==TestStepDetails.TestStepType.Module_Screen)
					{
						if(BusinessArea.equals(TS.ModuleName)==false)
						{
							BusinessArea=TS.ModuleName;
							test.log(Status.INFO, "=================Module: " + BusinessArea + "==============");
						}
						
						if(ScreenName.equals(TS.ScreenName)==false)
						{
							ScreenName=TS.ScreenName;
							test.log(Status.INFO, "=================Screen: " + ScreenName + "==============");
						}
					}
					
					
					
				}


			}
		}
		extent_lcl.flush();
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			System.out.println(e.getStackTrace());
			throw e;	
		}
	}


	public void AddScreenShotDetails(TestStepDetails TS,ExtentTest node )
	{
		if (TS.ScreenShotData.equals(""))
		{
			node.log(TS.ExtentStatus, TS.StepName);
		}
		else
		{
			node.log(TS.ExtentStatus,WriteImageToReport(TS.ScreenShotData, TS.StepName));
		}		
	}

	public String WriteDataToTextFile(String FilePath, String FileName,String FileContent,String FileFormat)
	{
		FilePath = FilePath + "/" + FileName + FileFormat;
		try
		{

			 BufferedWriter writer = new BufferedWriter(new FileWriter(FilePath));
		    writer.write(FileContent);
			    
			    writer.close();

			FilePath= FilePath.replace("\\","/");

			FilePath = "<a href = 'file:///"+ FilePath + "'>"+ FileName + "</a>";
			return FilePath;
		}
		
		catch (Exception e)
		{
			return FilePath;
		}
	}

	public String WriteImageToReport(String FilePath, String FileName)
	{
	
		try
		{
			FilePath = FilePath.replace("\\", "/");
			FilePath = "<a href = 'file:///" + FilePath + "'>" + FileName + "</a>";
			return FilePath;
		}

		catch (Exception e)
		{
			return FilePath;
		}
	}

}
