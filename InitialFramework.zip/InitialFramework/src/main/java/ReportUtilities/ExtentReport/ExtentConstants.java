package ReportUtilities.ExtentReport;

public class ExtentConstants
{
    public enum TestStepStatus { PASS, FAIL, DONE,SKIP };
}