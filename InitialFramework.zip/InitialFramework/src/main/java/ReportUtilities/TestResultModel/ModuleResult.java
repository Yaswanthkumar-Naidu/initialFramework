package ReportUtilities.TestResultModel;

public class ModuleResult {

	public String Module="";
	public int TCPassCount=0;
	public int TCFailCount=0;
	public int TCSkippedCount=0;
	public int TCTotalCount=0;
	
}
