package ReportUtilities.HTMLReport;

import ReportUtilities.Common.ReportCommon;
import ReportUtilities.Constants.HTMLReportContants;
import ReportUtilities.Constants.ReportContants;
import ReportUtilities.Model.ExtentModel.TestStepDetails;
import ReportUtilities.Model.HTML.HTMLTCLiveModel;
import ReportUtilities.Model.TestCaseParam;
import ReportUtilities.TestResultModel.BrowserResult;
import ReportUtilities.TestResultModel.ModuleResult;
import ReportUtilities.TestResultModel.TestCaseResult;
import com.aventstack.extentreports.ExtentTest;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.stream.Collectors;

public class HTMLReports {


	
	public static HashMap<String, String> TCHTMLMapping = new HashMap<String, String>();	


	public void GenerateReport(String ReportPath)
	{
		try {
			// Debugging paths
			System.out.println("Initial ReportPath: " + ReportPath);

			// generates HTML_Report_Summary.html
			ReportPath = ReportPath + HTMLReportContants.File_HTMLSummary;
			String ReportPath2 = ReportPath + File.separator + ".." + File.separator + ".." + File.separator + ".." + HTMLReportContants.File_HTMLSummary;

			// Debugging paths
			System.out.println("Final ReportPath: " + ReportPath);
			System.out.println("Alternate ReportPath2: " + ReportPath2);

			String ModuleResults = "";
			int i = 1;
			for (ModuleResult moduleResult : ReportContants.moduleResults) {
				String ModResult = HTMLReportContants.PlaceHolder_HTMLSummary_ModuleRow;

				ModResult = ModResult.replaceAll(HTMLReportContants.Summary_ModuleBrowser_SNO, String.valueOf(i));
				ModResult = ModResult.replaceAll(HTMLReportContants.Summary_ModuleBrowser_Module, String.valueOf(moduleResult.Module));
				ModResult = ModResult.replaceAll(HTMLReportContants.Summary_ModuleBrowser_TotalTC, String.valueOf(moduleResult.TCTotalCount));
				ModResult = ModResult.replaceAll(HTMLReportContants.Summary_ModuleBrowser_PassedTC, String.valueOf(moduleResult.TCPassCount));
				ModResult = ModResult.replaceAll(HTMLReportContants.Summary_ModuleBrowser_FailedTC, String.valueOf(moduleResult.TCFailCount));
				ModResult = ModResult.replaceAll(HTMLReportContants.Summary_ModuleBrowser_SkippedTC, String.valueOf(moduleResult.TCSkippedCount));

				ModuleResults = ModuleResults + ModResult;
				Thread.sleep(0);
				i++;
			}

			String BrowserResults = "";
			i = 1;
			for (BrowserResult browserResult : ReportContants.browserResults) {
				String BrResult = HTMLReportContants.PlaceHolder_HTMLSummary_BrowserRow;

				BrResult = BrResult.replaceAll(HTMLReportContants.Summary_ModuleBrowser_SNO, String.valueOf(i));
				BrResult = BrResult.replaceAll(HTMLReportContants.Summary_ModuleBrowser_Module, String.valueOf(browserResult.Browser));
				BrResult = BrResult.replaceAll(HTMLReportContants.Summary_ModuleBrowser_TotalTC, String.valueOf(browserResult.TCTotalCount));
				BrResult = BrResult.replaceAll(HTMLReportContants.Summary_ModuleBrowser_PassedTC, String.valueOf(browserResult.TCPassCount));
				BrResult = BrResult.replaceAll(HTMLReportContants.Summary_ModuleBrowser_FailedTC, String.valueOf(browserResult.TCFailCount));
				BrResult = BrResult.replaceAll(HTMLReportContants.Summary_ModuleBrowser_SkippedTC, String.valueOf(browserResult.TCSkippedCount));

				BrowserResults = BrowserResults + BrResult;
				i++;
			}

			ReportCommon reportCommon = new ReportCommon();

			String TestCaseResults = "";
			i = 1;
			for (TestCaseResult testCaseResult : ReportContants.testcaseResults) {
				String TCResult = HTMLReportContants.PlaceHolder_HTMLSummary_TCRow;

				TCResult = TCResult.replaceAll(HTMLReportContants.Summary_TC_SNO, String.valueOf(i));
				TCResult = TCResult.replaceAll(HTMLReportContants.Summary_TC_TCName, testCaseResult.TestCaseName);
				TCResult = TCResult.replaceAll(HTMLReportContants.Summary_TC_TCDesc, testCaseResult.TestCaseDescription);
				TCResult = TCResult.replaceAll(HTMLReportContants.Summary_TC_Module, testCaseResult.Module);
				TCResult = TCResult.replaceAll(HTMLReportContants.Summary_TC_Browser, testCaseResult.Browser);
				TCResult = TCResult.replaceAll(HTMLReportContants.Summary_TC_Status, testCaseResult.TestCaseStatus);
				TCResult = TCResult.replaceAll(HTMLReportContants.Summary_TC_StartTime, reportCommon.ConvertLocalDateTimetoSQLDateTime(testCaseResult.StartTime));
				TCResult = TCResult.replaceAll(HTMLReportContants.Summary_TC_EndTime, reportCommon.ConvertLocalDateTimetoSQLDateTime(testCaseResult.EndTime));
				TCResult = TCResult.replaceAll(HTMLReportContants.Summary_TC_Duration, reportCommon.getTimeDifference(testCaseResult.StartTime, testCaseResult.EndTime));

				TestCaseResults = TestCaseResults + TCResult;
				i++;
			}

			String HTMLResultsSummary = HTMLReportContants.PlaceHolder_HTMLSummary;
			HTMLResultsSummary = HTMLResultsSummary.replaceAll(HTMLReportContants.Summary_DataRow_Module, ModuleResults);
			HTMLResultsSummary = HTMLResultsSummary.replaceAll(HTMLReportContants.Summary_DataRow_Browser, BrowserResults);
			HTMLResultsSummary = HTMLResultsSummary.replaceAll(HTMLReportContants.Summary_DataRow_TC, TestCaseResults);

			// Write data to text files
			WriteDataToTextFile(ReportPath, HTMLResultsSummary);
			WriteDataToTextFile(ReportPath2, HTMLResultsSummary);

			WriteDataToTextFile(HTMLReportContants.HTMLReportsDir + File.separator + HTMLReportContants.SummaryDashboard, HTMLReportContants.SummaryData_HTML);
			WriteFileLineByLine(HTMLReportContants.HTMLReportsDir + File.separator + HTMLReportContants.SummaryCSS, HTMLReportContants.SummaryData_CSS);
			WriteFileLineByLine(HTMLReportContants.HTMLReportsDir + File.separator + HTMLReportContants.SummaryJS, HTMLReportContants.HTMLSummaryData_JS);

//			// Copy the final report to another easily accessible location
//			String copyReportPath = "Results" + File.separator + "HTML_Report_Summary.html";
//			System.out.println("Report generated at: " + copyReportPath);

		} catch (Exception e) {
			System.out.println("Unable to Create the HTML Report");
			e.printStackTrace();
		}

		}


	public String CreateTCHTML(String TestCase,String ModuleName, String Browser, String TestCaseDescription)
	{
		String TCHTMLPath="";
		String TCHTMLIndex="";
		try
		{
		

		String TCDir=HTMLReportContants.HTMLReportsDir+TestCase+"_"+ ModuleName+ "_" + Browser;
		TCHTMLIndex=TCDir+HTMLReportContants.File_HTMLIndex;
		TCHTMLPath=TCDir+ HTMLReportContants.File_HTMLTestCase;
		String TCHTMLData=HTMLReportContants.PlaceHolder_HTMLTestCase;
		
		String TSHTMLPath=TCDir+ HTMLReportContants.File_TestStep;
		String TSHTMLData=HTMLReportContants.PlaceHolder_TestStepPre;

		String TCIndexPath=TCDir+ HTMLReportContants.File_HTMLIndex;
		
		File dir = new File(TCDir);
        if (!dir.exists()) dir.mkdirs();

        TCHTMLData=TCHTMLData.replaceAll(HTMLReportContants.TC_Name,TestCase);
        TCHTMLData=TCHTMLData.replaceAll(HTMLReportContants.TC_Module,ModuleName);
        TCHTMLData=TCHTMLData.replaceAll(HTMLReportContants.TC_Browser,Browser);
        TCHTMLData=TCHTMLData.replaceAll(HTMLReportContants.TC_Status,"InProgress");
        TCHTMLData=TCHTMLData.replaceAll(HTMLReportContants.PageRefreshTimeInSecondsVar,HTMLReportContants.PageRefreshTimeInSeconds);
        TSHTMLData=TSHTMLData.replaceAll(HTMLReportContants.PageRefreshTimeInSecondsVar,HTMLReportContants.PageRefreshTimeInSeconds);
        
        
        WriteDataToTextFile(TCHTMLPath, TCHTMLData);
        
        WriteDataToTextFile(TSHTMLPath, TSHTMLData);
        
        WriteDataToTextFile(TCIndexPath, HTMLReportContants.PlaceHolder_HTMLIndex);
        
        System.out.println("================================================================================================= ");
        System.out.println("HTML Report for Test Case : "+ TestCase);
        System.out.println("================================================================================================= ");
        
        System.out.println( "<a href = 'file:///"+ TSHTMLPath + "'>"+ TestCase + "</a>");
        
        System.out.println("================================================================================================= ");
        System.out.println("================================================================================================= ");
		}
		catch(Exception e)
		{
		System.out.println("Unable to initialize the HTML Test Case Report==>"+TestCase );
		System.out.println(e.getStackTrace());
		System.out.println(e.getMessage());
		}

		return TCHTMLIndex;
	
	}

	
	
	public String CreateTCHTMLLiveSummary()
	{

		
		String HTMLTCLiveReportFile=HTMLReportContants.HTMLReportsDir+HTMLReportContants.HTML_TCLiveReport;
		
		try
		{
		


		
		String TCHTMLLiveReport=HTMLReportContants.PlaceHolder_HTMLTCLiveTemplate;
        WriteDataToTextFile(HTMLTCLiveReportFile, TCHTMLLiveReport);
        
        
        System.out.println("================================================================================================= ");
        System.out.println("HTML Live Report for all Test Cases : ");
        System.out.println("================================================================================================= ");
        
        System.out.println( "<a href = 'file:///"+ HTMLTCLiveReportFile + "'>Test Cases Details</a>");
        
        System.out.println("================================================================================================= ");
        System.out.println("================================================================================================= ");

		}
		catch(Exception e)
		{
		System.out.println("Unable to initialize the HTML Live Report==>"+HTMLTCLiveReportFile );
		System.out.println(e.getStackTrace());
		System.out.println(e.getMessage());
		}
		
		return HTMLTCLiveReportFile;
	
	}
	public String Create_Dashboard_HTMLLiveSummary()
	{

		String HTMLTCLiveReportFile=HTMLReportContants.HTMLReportsDir +"/" + HTMLReportContants.SummaryDashboard;
		try
		{
			WriteDataToTextFile(HTMLReportContants.HTMLReportsDir +"/" + HTMLReportContants.SummaryDashboard , HTMLReportContants.SummaryData_HTML);
			WriteFileLineByLine(HTMLReportContants.HTMLReportsDir +"/" + HTMLReportContants.SummaryCSS , HTMLReportContants.SummaryData_CSS);
			WriteFileLineByLine(HTMLReportContants.HTMLReportsDir +"/" + HTMLReportContants.SummaryJS , HTMLReportContants.HTMLSummaryData_JS);
			System.out.println("================================================================================================= ");
			System.out.println("HTML Live Report for all Test Cases : ");
			System.out.println("================================================================================================= ");

			System.out.println( "<a href = '"+ HTMLTCLiveReportFile + "'>Live Dashboard</a>");

			System.out.println("================================================================================================= ");
			System.out.println("================================================================================================= ");

		}
		catch(Exception e)
		{
			System.out.println("Unable to initialize the HTML Live Report==>"+HTMLTCLiveReportFile );
			System.out.println(e.getStackTrace());
			System.out.println(e.getMessage());
		}

		return HTMLTCLiveReportFile;
	}

	public void CreateTCHTMLLive(String TestCase,String ModuleName, String Browser, String Status,String TCFilePath)
	{
		try
		{
		

		String HTMLTCLiveReportFile=HTMLReportContants.HTMLReportsDir+HTMLReportContants.HTML_TCLiveReport;
		
		String TCHTMLLiveReport=HTMLReportContants.PlaceHolder_HTMLTCLiveTemplate;

		TCHTMLLiveReport=TCHTMLLiveReport.replaceAll(HTMLReportContants.PageRefreshTimeInSecondsVar,HTMLReportContants.PageRefreshTimeInSeconds);
		TCHTMLLiveReport=TCHTMLLiveReport.replaceAll(HTMLReportContants.PageRefreshTimeInSecondsVar,HTMLReportContants.PageRefreshTimeInSeconds);

		
		ReportContants.htmlTCLiveModels.add(new HTMLTCLiveModel().AddData_HTMLTCLiveModel(TestCase, ModuleName, Browser, Status, TCFilePath));


		
		for(HTMLTCLiveModel htmltcLiveModel: ReportContants.htmlTCLiveModels)
		{
			String HTMLTCLiveRow=HTMLReportContants.PlaceHolder_HTMLTCLiveRow;
			HTMLTCLiveRow=HTMLTCLiveRow.replace(HTMLReportContants.TCLive_TCName , htmltcLiveModel.TestCase);
			HTMLTCLiveRow=HTMLTCLiveRow.replace(HTMLReportContants.TCLive_Module , htmltcLiveModel.Module);
			HTMLTCLiveRow=HTMLTCLiveRow.replace(HTMLReportContants.TCLive_Browser , htmltcLiveModel.Browser);
			HTMLTCLiveRow=HTMLTCLiveRow.replace(HTMLReportContants.TCLive_Status , htmltcLiveModel.Status);
			htmltcLiveModel.FilePath = (htmltcLiveModel.FilePath.split("HTMLReports")[1]).substring(1);
			HTMLTCLiveRow=HTMLTCLiveRow.replace(HTMLReportContants.TCLive_FilePath , htmltcLiveModel.FilePath);
			
			TCHTMLLiveReport=TCHTMLLiveReport+HTMLTCLiveRow;
			
		}
        WriteDataToTextFile(HTMLTCLiveReportFile, TCHTMLLiveReport);
        
		}
		catch(Exception e)
		{
		System.out.println("Unable to initialize the HTML Test Case Report==>"+TestCase );
		System.out.println(e.getStackTrace());
		System.out.println(e.getMessage());
		}
	
		
	
	}


	public void UpdateTCHTMLLive(String TestCase,String ModuleName, String Browser, String Status)
	{
		try
		{
		

		String HTMLTCLiveReportFile=HTMLReportContants.HTMLReportsDir+HTMLReportContants.HTML_TCLiveReport;
		
		String TCHTMLLiveReport=HTMLReportContants.PlaceHolder_HTMLTCLiveTemplate;
		TCHTMLLiveReport=TCHTMLLiveReport.replaceAll(HTMLReportContants.PageRefreshTimeInSecondsVar,HTMLReportContants.PageRefreshTimeInSeconds);
		TCHTMLLiveReport=TCHTMLLiveReport.replaceAll(HTMLReportContants.PageRefreshTimeInSecondsVar,HTMLReportContants.PageRefreshTimeInSeconds);


		
		ReportContants.htmlTCLiveModels = ReportContants.htmlTCLiveModels.stream()
                .map(row -> {
                    if (row.getTestCase().equals(TestCase) && row.getModule().equals(ModuleName) && row.getBrowser().equals(Browser)) {
                    	row.setStatus(Status);
                    }
                    return row;
                })
                .collect(Collectors.toList());

		
		for(HTMLTCLiveModel htmltcLiveModel: ReportContants.htmlTCLiveModels)
		{
			String HTMLTCLiveRow=HTMLReportContants.PlaceHolder_HTMLTCLiveRow;
			HTMLTCLiveRow=HTMLTCLiveRow.replace(HTMLReportContants.TCLive_TCName , htmltcLiveModel.TestCase);
			HTMLTCLiveRow=HTMLTCLiveRow.replace(HTMLReportContants.TCLive_Module , htmltcLiveModel.Module);
			HTMLTCLiveRow=HTMLTCLiveRow.replace(HTMLReportContants.TCLive_Browser , htmltcLiveModel.Browser);
			HTMLTCLiveRow=HTMLTCLiveRow.replace(HTMLReportContants.TCLive_Status , htmltcLiveModel.Status);
			HTMLTCLiveRow=HTMLTCLiveRow.replace(HTMLReportContants.TCLive_FilePath , htmltcLiveModel.FilePath);
			TCHTMLLiveReport=TCHTMLLiveReport+HTMLTCLiveRow;
		}
		
		
        WriteDataToTextFile(HTMLTCLiveReportFile, TCHTMLLiveReport);
        
		}
		catch(Exception e)
		{
		System.out.println("Unable to initialize the HTML Test Case Report==>"+TestCase );
		System.out.println(e.getStackTrace());
		System.out.println(e.getMessage());
		}
	
	}

	

	public void addTestStepsLogs(TestCaseParam testCaseParam, TestStepDetails TSDetails)
	{

		try
		{
			String TCDir=HTMLReportContants.HTMLReportsDir+testCaseParam.TestCaseName +"_"+ testCaseParam.ModuleName+ "_" + testCaseParam.Browser;
			String SCHTMLPath=TCDir+ HTMLReportContants.File_ScreenShot;
			String SCHTMLData=HTMLReportContants.PlaceHolder_ScreenShot;
			
			String TSHTMLPath=TCDir+ HTMLReportContants.File_TestStep;
			String TSHTMLData=HTMLReportContants.PlaceHolder_CurrentTestStep;
		

			SCHTMLData=SCHTMLData.replaceAll(HTMLReportContants.Scr_StepName,TSDetails.StepName);
			SCHTMLData=SCHTMLData.replaceAll(HTMLReportContants.PageRefreshTimeInSecondsVar,HTMLReportContants.PageRefreshTimeInSeconds);

			
	        WriteDataToTextFile(SCHTMLPath, SCHTMLData);
			
	        TSHTMLData=TSHTMLData.replaceAll(HTMLReportContants.TS_StepName,TSDetails.StepName);
	        TSHTMLData=TSHTMLData.replaceAll(HTMLReportContants.TS_StepDesc,TSDetails.StepDescription);
	        TSHTMLData=TSHTMLData.replaceAll(HTMLReportContants.TS_Status,TSDetails.testCaseStatus);
	        if(TSDetails.ScreenShotData.equals(""))
	        {
	        TSHTMLData=TSHTMLData.replaceAll(HTMLReportContants.TS_Screenshot,"N/A");
	        }
	        else
	        {
	        	
	        	String ScrLink=WriteImageToReport(TSDetails.ScreenShotData,"Screenshot");
	        	
		        TSHTMLData=TSHTMLData.replaceAll(HTMLReportContants.TS_Screenshot,ScrLink);	
		        String ScreenshotPath=TCDir+ "/" + HTMLReportContants.File_ScreenShotImage;
		        copyFileUsingStream(TSDetails.ScreenShotData, ScreenshotPath);
		        
	        }
	        
	        ReportCommon reportCommon =new ReportCommon();
	        
	        TSHTMLData=TSHTMLData.replace(HTMLReportContants.TS_StartTime,reportCommon.ConvertLocalDateTimetoSQLDateTime(TSDetails.StartTime));
	        TSHTMLData=TSHTMLData.replace(HTMLReportContants.TS_EndTime,reportCommon.ConvertLocalDateTimetoSQLDateTime(TSDetails.EndTime));
	        
	        TSHTMLData=TSHTMLData.replaceAll(HTMLReportContants.TS_Duration,reportCommon.getTimeDifference(TSDetails.StartTime,TSDetails.EndTime));
			
	        AppendDataToTextFile(TSHTMLPath, TSHTMLData);
		}
		catch(Exception e)
		{
			System.out.println("Unable to update the Extent Test Step ==>"+TSDetails.StepName );
			System.out.println(e.getStackTrace());
			System.out.println(e.getMessage());
			
			
			
		}



	}

	
	

	public void AddScreenShotDetails(TestStepDetails TS,ExtentTest node )
	{
		if (TS.ScreenShotData.equals(""))
		{
			node.log(TS.ExtentStatus, TS.StepName);
		}
		else
		{
			node.log(TS.ExtentStatus,WriteImageToReport(TS.ScreenShotData, TS.StepName));
		}		
	}



	public String ReadDataFromTextFile(String FilePath)
	{

		 String data="";
		try
		{
Thread.sleep(0);
			 BufferedReader reader = new BufferedReader(new FileReader(FilePath));
		   
		    String strCurrentLine="";
		    		
		    		 while ((strCurrentLine = reader.readLine()) != null) {
		    			 data=data+strCurrentLine;
		    			   }
			return data;
		}
		
		catch (Exception e)
		{
			return data;
		}
	}


	public ArrayList<String> ReadFileLineByLine(String FilePath)
	{

		ArrayList<String> data = new ArrayList<String>();
		try
		{
Thread.sleep(0);
			 BufferedReader reader = new BufferedReader(new FileReader(FilePath));
		   
		    String strCurrentLine="";
		    		
		    		 while ((strCurrentLine = reader.readLine()) != null) {
		    			 data.add(strCurrentLine);
		    			   }
			return data;
		}
		
		catch (Exception e)
		{
			return data;
		}
	}

	

	
	
	public String WriteDataToTextFile(String FilePath,String FileContent)
	{

		try
		{

			 BufferedWriter writer = new BufferedWriter(new FileWriter(FilePath));
		    writer.write(FileContent);
			    
			    writer.close();


			return FilePath;
		}
		
		catch (Exception e)
		{
			return FilePath;
		}
	}

	
	public void WriteFileLineByLine(String FilePath,ArrayList<String> FileContent)
	{

		try (BufferedWriter writer = new BufferedWriter(new FileWriter(FilePath))) {
	        for (String line : FileContent) {
	            writer.write(line);
	            writer.newLine(); // To add a newline after each line
	        }
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}


	
	public String AppendDataToTextFile(String FilePath,String FileContent)
	{

		try
		{

			 BufferedWriter writer = new BufferedWriter(new FileWriter(FilePath,true));
		    writer.write(FileContent);
			    
			    writer.close();


			return FilePath;
		}
		
		catch (Exception e)
		{
			return FilePath;
		}
	}

	public String WriteImageToReport(String FilePath, String FileName)
	{
	
		try
		{
			FilePath = FilePath.replace("\\", "/");
			FilePath = "<a href = 'file:///" + FilePath + "'>" + FileName + "</a>";
			return FilePath;
		}

		catch (Exception e)
		{
			return FilePath;
		}
	}


	
	public void copyFileUsingStream(String sourcePath, String destPath) throws IOException {
	
		
		File source= new File(sourcePath);
		File dest = new File(destPath);
		
		InputStream is = null;
	    OutputStream os = null;
	    try {
	        is = new FileInputStream(source);
	        os = new FileOutputStream(dest);
	        byte[] buffer = new byte[1024];
	        int length;
	        while ((length = is.read(buffer)) > 0) {
	            os.write(buffer, 0, length);
	        }
	    	}
	        catch(Exception e)
	        {
	        	System.out.println("Unable to Copy the Files   ===>>Source: "+ sourcePath + " Destination ===> "+ destPath);
	        }
	    	finally {
	        is.close();
	        os.close();
	    }
	}
}
