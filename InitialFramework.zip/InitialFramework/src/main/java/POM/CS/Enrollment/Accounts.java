package POM.CS.Enrollment;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import CommonUtilities.Common.ActionKeywords.WebKeywords;
import Constants.ModuleConstants_CS;
import Constants.ScreenConstants_CS;
import POM.CS.Login.CS_Login;
import TestSettings.TestRunSettings;
import UITests.TestNG.Common.CS.TC_Enrollmentscreen;
import UITests.TestNG.Common.ExcelUtility;
import org.slf4j.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import ReportUtilities.Common.ReportCommon;
import ReportUtilities.Common.ScreenshotCommon;
import ReportUtilities.Model.TestCaseParam;
import ReportUtilities.Model.ExtentModel.PageDetails;

public class Accounts {

    private static final Logger logger = LoggerFactory.getLogger(CS_Login.class.getName());
    private final WebDriver driver;
    ExcelUtility excelutil = new ExcelUtility();
    ScreenshotCommon SCM = new ScreenshotCommon();
    ReportCommon exceptionDetails = new ReportCommon();

    HashMap<String, ArrayList<String>> TestCaseData_CS = new HashMap<String, ArrayList<String>>();
    String ScreenName = ScreenConstants_CS.EnrolmentScreen;
    String ModuleName = ModuleConstants_CS.Accounts;

    public Accounts(WebDriver _driver, TestCaseParam testCaseParam) throws Exception {
        driver = _driver;
        PageFactory.initElements(driver, this);
        ReportCommon TestStepLogDetails = new ReportCommon();
       
        //call your respective method
       
    }

    //add your Respective Xpaths
    @FindBy(how = How.XPATH, using = "//div[@role='navigation']/descendant::button")
    public WebElement Globalappbutton;
    public WebElement ClickTOL;
    @FindBy(how = How.XPATH, using = "//label[contains(text(),'Type of License')]/../div/descendant::button/../following-sibling::div/lightning-base-combobox-item/span/span[text()='Occupational']")
    public WebElement TOL;
    @FindBy(how = How.XPATH, using = "//button[@name='SaveBtn']/div/div")
    public WebElement SaveME;

}
