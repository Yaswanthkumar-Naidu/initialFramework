package CommonUtilities.Common;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;

import org.slf4j.*;

public class RetreiveProperties
{
    private static final Logger logger =LoggerFactory.getLogger(RetreiveProperties.class.getName());

    public HashMap<String, String> GetProperties(String path) throws Exception
    {
        try
        {

            String fileData = new String(Files.readAllBytes(Paths.get(path)), StandardCharsets.UTF_8);
                fileData = fileData.replace("\r", "");
            HashMap<String, String> Properties = new HashMap<String, String>();
            String[] kvp;
            String[] records = fileData.split("\n");
            for (String record : records)
            {
                if (record.trim().startsWith("//") == false)
                {
                    if (record.contains("="))
                    {
                        kvp = record.split("=");
                        if (Properties.containsKey(kvp[0].trim()) == false)
                        {
                            Properties.put(kvp[0].trim(), kvp[1].trim());
                        }
                    }
                }
            }
            return Properties;

        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
            logger.error(e.getMessage());
            logger.error("StackTrace:"+e.getStackTrace());

            throw e;
        }
    }
}
