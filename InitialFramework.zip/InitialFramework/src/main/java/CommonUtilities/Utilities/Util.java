package CommonUtilities.Utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.Random;

import org.slf4j.*;
import org.openqa.selenium.WebDriver;

import CommonUtilities.Common.POI_ReadExcel;


import com.github.javafaker.Faker;

import CommonUtilities.Common.RetreiveProperties;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;


public class Util
{
    private static final Logger logger =LoggerFactory.getLogger(Util.class.getName()); 

    public enum Mode
    {
        ALPHA, ALPHANUMERIC, NUMERIC
    }
    public static String getRootPath(){
    return Paths.get("").toAbsolutePath().toString();
    }
    public Util()
    {

    }

    /// <summary>
    /// This method is to fetch Data from the column in the Input sheet against the test case that is currently executing based on the current iteration
    /// </summary>
    /// Author : Jigesh Shah
    /// <param name="colName">Name of the Column from the Data Sheet</param>
    /// <param name="driver">WebDriver Instance</param>
    /// <param name="scenario">Name of the Scenario</param>
    /// <param name="testCase">Name of the Test Case</param>
    /// <param name="homePath">Path of the Solution Folder</param>
    /// <param name="currentIteration">Index of the the current Iteration</param>
    /// <param name="browser">Browser Name</param>
    /// <param name="passScreenshot">Path of the Screenshot folder for a Passed Step</param>
    /// <param name="browserFolder">Folder location of the browser Type</param>
    /// <returns></returns>
    public String getData(String colName, WebDriver driver,String Module, String scenario, String testCase, String homePath, Integer currentIteration, String browser, String passScreenshot, String browserFolder) {
	String dataValue = "";


	
	String dbPath = homePath + "/test/resources/TestScripts-TestData/"+scenario+".csv";
	POI_ReadExcel poiObject = new POI_ReadExcel();
//	Report reportObject = new Report();
	try {
		// TODO Auto-generated method stub

		ArrayList<String> whereClause = new ArrayList<String>();
		whereClause.add("TestScript::"+testCase);
		whereClause.add("Iteration::"+Integer.parseInt(currentIteration.toString()));
		HashMap<String, ArrayList<String>> result = poiObject.fetchWithCondition(dbPath, "TestData", whereClause);

		if(result.get("TestScript").size() ==0){
      //          TestStepLog TestStepLogObject = new TestStepLog();
        //        TestStepLogObject.Log("Blank column in Test Data", "There is no data in the column "+colName+" for the Iteration "+currentIteration+" of test case "+testCase, Report.Status.FAIL, driver, testCase, scenario,Module, browser, passScreenshot, browserFolder);
		}

		for(int i=0; i<result.get("TestScript").size(); i++){
            if (testCase.equals(result.get("TestScript").get(i)) && Integer.parseInt(currentIteration.toString()) == Integer.parseInt(result.get("Iteration").get(i)))
            {
                    //System.out.println("ColName: " + colName + " :: " + "i: " + i);
                    //System.out.println("Result: " + result[colName][i]);
                    dataValue = result.get(colName).get(i);
				break;
			}
		}

		return dataValue;
	} catch (Exception e) {
            System.out.println(e.getMessage());   logger.error(e.getMessage());
            logger.error( "StackTrace:"+e.getStackTrace());
            
     //       TestStepLog TestStepLogObject = new TestStepLog();
       //     TestStepLogObject.Log("Unhandled Exception in reading Data", "There has been an unhandled exception "+e+" while reading data from the Test Data sheet", Report.Status.FAIL, driver, testCase, scenario,Module, browser, passScreenshot, browserFolder);
		throw e;
	}

}



    public HashMap<String, ArrayList<String>> getDictionaryFromPOI(String path,String SheetName,String Clause)
    {

        try
        { 
        POI_ReadExcel poiObject = new POI_ReadExcel();
        ArrayList<String> whereClause_Web_TotalCount = new ArrayList<String>();
        whereClause_Web_TotalCount.add(Clause);
        return poiObject.fetchWithCondition(path, SheetName, whereClause_Web_TotalCount);
    } catch (Exception e) {
            System.out.println(e.getMessage()); 
            logger.error(e.getMessage());
            logger.error( "StackTrace:"+e.getStackTrace());
            
           // TestStepLog TestStepLogObject = new TestStepLog();
  			throw e;
	}
}

    public HashMap<String,String> getTestData(String TDPath, String TestDataSheet,WebDriver driver, String scenario, String testCase, String homePath, Integer currentIteration, String browser, String passScreenshot, String browserFolder)
    {
    //    Report reportObject = new Report();
        try
        {
        	


            ArrayList<String> TestDataSheets = (ArrayList<String>) List.of(TestDataSheet.split(";"));
        HashMap<String, String> TestData = new HashMap<String, String>();

        for (String TD : TestDataSheets)
        { 
        String TestDataPath = TDPath + TD + ".csv";

        POI_ReadExcel poiObject = new POI_ReadExcel();
                // TODO Auto-generated method stub




                ArrayList<String> whereClause_TestData = new ArrayList<String>();
                whereClause_TestData.add("TestScript::" + testCase.toString());
                whereClause_TestData.add("Iteration::" + currentIteration.toString());
                HashMap<String, ArrayList<String>> result = poiObject.fetchWithCondition(TestDataPath, "TestData", whereClause_TestData);
         
                

                if (result.get("Iteration").size() == 0)
                {
                 //   TestStepLog TestStepLogObject = new TestStepLog();
      //              TestStepLogObject.Log("Blank column in Test Data", "There is no data in the column  for the Iteration " + currentIteration.toString() + " of test case " + testCase, Report.Status.FAIL, driver, testCase, scenario,"", browser, passScreenshot, browserFolder);
                }

                for (String key : result.keySet())
                {

                    if (TestData.containsKey(key) == false)
                    {
                        TestData.put(key,result.get(key).get(0));
                    }
                    else
                    {
                        TestData.replace(key,result.get(key).get(0));
                    }
                }

            }
            return TestData;
        }
        catch (Exception e)
        {


            System.out.println(e.getMessage()); logger.error(e.getMessage());
            logger.error( "StackTrace:"+e.getStackTrace());
            
            throw e;
        }

    }

    /// <summary>
    /// This method gets the Current Date in the format 'MM-dd-yyyy'
    /// </summary>
    /// Author : Jigesh Shah
    /// <returns>Current Date in String Format</returns>
    public static String getCurrentDate(){

        try { 
    LocalDateTime today = LocalDateTime.now();
    DateTimeFormatter format = DateTimeFormatter.ofPattern("MM-dd-yyyy");
    String date = today.format(format);
    date = date.replace(":", "_");
    date = date.replace(" ", "_");
    date = date.replace(".", "_");
    date = date.replace("-", "_");
    return date;
    }
        catch(Exception e)
        {
            System.out.println(e.getMessage());   logger.error(e.getMessage());
            logger.error( "StackTrace:"+e.getStackTrace());
            
            throw e;
        }
}

    /// <summary>
    /// This method is get the Current Time in the format 'hh-mm-ss'
    /// </summary>
    /// Author: Jigesh Shah
    /// <returns>Current Time in String Format</returns>
    public static String getCurrentTime(){
        try { 
        	 Date date = Calendar.getInstance().getTime();
			   DateFormat dateFormat = new SimpleDateFormat("hh:mm:ss.sss");
			   String result = dateFormat.format(date);
			   result = result.replace(":", "_");
            result = result.replace(" ", "_");
            result = result.replace(".", "_");
    return result;

    }
        catch(Exception e)
        {
            System.out.println(e.getMessage());   logger.error(e.getMessage());
            logger.error( "StackTrace:"+e.getStackTrace());
            
            throw e;
        }

}


/**
 * Author: Santosh Kumar Anupati
 * Method Name: getData
 * Description: This method is to fetch Data from the column in the Input sheet against the test case that is currently executing based on the current iteration
 * Return Type: String
 * @throws Exception 
 */
public String getReusableData(String colName, WebDriver driver, String scenario, String testCase, String homePath, Integer currentIteration, String browser, String passScreenshot, String browserFolder) {
	String dataValue = "";
	

	
	String dbPath = homePath + "/test/resources/TestScripts-TestData/"+scenario+".csv";
	POI_ReadExcel poiObject = new POI_ReadExcel();
	//Report reportObject = new Report();
	try {
		// TODO Auto-generated method stub
		
		ArrayList<String> whereClause = new ArrayList<String>();
		whereClause.add("TestScript::"+testCase);
		whereClause.add("Iteration::"+ Integer.parseInt(currentIteration.toString()));
		HashMap<String, ArrayList<String>> result = poiObject.fetchWithCondition(dbPath, "TestData", whereClause);
		
		if(result.get("TestScript").size()==0){
      //          TestStepLog TestStepLogObject = new TestStepLog();
   //             TestStepLogObject.Log("Blank column in Test Data", "There is no data in the column "+colName+" for the Iteration "+currentIteration+" of test case "+testCase, Report.Status.FAIL, driver, testCase, scenario,"", browser, passScreenshot, browserFolder);
		}
		
		for(int i=0; i<result.get("TestScript").size(); i++){
            if (testCase.equalsIgnoreCase(result.get("TestScript").get(i)) && Integer.parseInt(currentIteration.toString()) == Integer.parseInt(result.get("Iteration").get(i)))
            {
				dataValue = result.get(colName).get(i);
				break;
			}
		}
		
		return dataValue;
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());   logger.error(e.getMessage());
            logger.error( "StackTrace:"+e.getStackTrace());
            
            throw e;
        }

    }


    /// <summary>
    /// This method will create a directory for Business Module
    /// </summary>
    /// <param name="resultsPath"></param>
    /// <param name="scenario"></param>
    /// <returns></returns>
    public String CreateModuleFolder(String resultsPath, String module)
    {

        try
        {

        	File dir = new File(resultsPath + "/" + module);
            if (!dir.exists()) dir.mkdirs();
           

            return (resultsPath + "/" + module);


        }
        catch (Exception e)
        {
            System.out.println(e.getMessage()); logger.error(e.getMessage());
            logger.error( "StackTrace:"+e.getStackTrace());
            
            throw e;
        }
    }


    /// <summary>
    /// This method is to create the Scenario folder for the current executing scenario
    /// </summary>
    ///  Author: Jigesh Shah
    /// <param name="resultsPath">Path of the Results Folder</param>
    /// <param name="scenario">Name of the Scenario</param>
    /// <returns></returns>
    public String CreateScenarioFolder(String resultsPath, String scenario)
    {

        try
        {

        	File dir = new File(resultsPath + "/" + scenario);
            if (!dir.exists()) dir.mkdirs();
            return (resultsPath + "/" + scenario);


        }
        catch (Exception e)
        {
            System.out.println(e.getMessage()); logger.error(e.getMessage());
            logger.error( "StackTrace:"+e.getStackTrace());
            
            throw e;
        }
    }

    /// <summary>
    ///  This method is to create the current Browser folder within the scenario folder
    /// </summary>
    ///  Author: Jigesh Shah
    /// <param name="scenarioFolderPath">Path of the Scenario Folder</param>
    /// <param name="browser">Browser Type</param>
    /// <returns></returns>
    public String CreateBrowserFolder(String scenarioFolderPath, String browser)
    {

        try
        {
        	File dir = new File(scenarioFolderPath + "/" + browser);
            if (!dir.exists()) dir.mkdirs();
            return (scenarioFolderPath + "/" + browser);

        }
        catch (Exception e)
        {
            System.out.println(e.getMessage()); logger.error(e.getMessage());
            logger.error( "StackTrace:"+e.getStackTrace());
            
            throw e;
        }
    }



    public HashMap<String,String> getORElements(String ORPath, String ORFileNames) throws Exception
    {
        String value = "";
        HashMap<String, String> ObjRep = new HashMap<String, String>();
        ArrayList<String> ORFiles = (ArrayList<String>) List.of(ORFileNames.split(";"));

        for (String ORFile : ORFiles)
        {
               try
            {
   
                String propFile = ORPath + ORFile + ".txt";
                RetreiveProperties RP = new RetreiveProperties();
                HashMap<String, String> TempObjRep = RP.GetProperties(propFile);


                for (String key : TempObjRep.keySet())

                {

                    if (ObjRep.containsKey(key) == false)
                    {
                        ObjRep.put(key, TempObjRep.get(key));
                    }
                    else
                    {
                        ObjRep.replace(key, TempObjRep .get(key)) ;
                    }
                }


            }
            catch (FileNotFoundException e1)
            {
                // TODO Auto-generated catch block
                System.out.println(e1.getMessage());
            }
            catch (IOException e1)
            {
                // TODO Auto-generated catch block
                System.out.println(e1.getMessage());
            }
            catch (Exception e)
            {
                System.out.println(e.getMessage()); logger.error(e.getMessage());
                logger.error( "StackTrace:"+e.getStackTrace());
                
                throw e;
            }
        }
        return ObjRep;
    }


    /**
     * Author: Santosh Kumar Anupati
     * Method Name: getObjectFromObjectMap
     * Description: This method is to retrieve object from the particular module ObjectMap.properties file for the key given
     * Return Type: String
     * @throws Exception 
     */
    public String getObjectFromObjectMap(String key, String scenario,String HomePath) throws Exception{
	String value = "";

	try {
        
         

            String propFile = HomePath + "/test/resources/ObjectRepository/" + scenario + ".txt";
        RetreiveProperties RP = new RetreiveProperties();
        HashMap<String, String> ObjRep = RP.GetProperties(propFile);


		if(key!="")
            value = ObjRep.get(key);
		else
			value = null;
	} catch (FileNotFoundException e1) {
		// TODO Auto-generated catch block
        System.out.println(e1.getMessage());
	} catch (IOException e1) {
		// TODO Auto-generated catch block
        System.out.println(e1.getMessage());
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());   logger.error(e.getMessage());
            logger.error( "StackTrace:"+e.getStackTrace());
            
            throw e;
        }
        return value;
}

    public HashMap<String, String> getObjectFromCommonRep(String HomePath) throws Exception
    {
        String value = "";
        HashMap<String, String> ObjRep = new HashMap<String, String>();
        try
        {
           

            String propFile = HomePath + "/test/resources/ObjectRepository/Common.txt";
            RetreiveProperties RP = new RetreiveProperties();
            ObjRep = RP.GetProperties(propFile);


       
        }
        catch (FileNotFoundException e1)
        {
            // TODO Auto-generated catch block
            System.out.println(e1.getMessage());
        }
        catch (IOException e1)
        {
            // TODO Auto-generated catch block
            System.out.println(e1.getMessage());
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());   logger.error(e.getMessage());
            logger.error( "StackTrace:"+e.getStackTrace());
            
            throw e;
        }
        return ObjRep;
    }


    /**
     * Author: Prashant Thakuri
     * Method Name: getDataForAppiumTC
     * Description: This method will return back the data from the test Data sheet for Appium Test cases.
     * Return Type: String
     */

    public String getDataValueForAppiumTC(String colName, WebDriver driver, String scenario, String testCase, String dataPath, Integer currentIteration, String browser, String passScreenshot, String browserFolder) {
	String dataValue = "";
	String dbPath = dataPath;
	POI_ReadExcel poiObject = new POI_ReadExcel();

	try {
		// TODO Auto-generated method stub

		ArrayList<String> whereClause = new ArrayList<String>();
		whereClause.add("TestScript::"+testCase);
		whereClause.add("Iteration::"+currentIteration.toString());
		HashMap<String, ArrayList<String>> result = poiObject.fetchWithCondition(dbPath, "TestData", whereClause);

		if(result.get("TestScript").size()==0){
        //        TestStepLog TestStepLogObject = new TestStepLog();
           //     TestStepLogObject.Log("Blank column in Test Data", "There is no data in the column "+colName+" for the Iteration "+currentIteration+" of test case "+testCase, Report.Status.FAIL, driver, testCase, scenario,"", browser, passScreenshot, browserFolder);
		}

		for(int i=0; i<result.get("TestScript").size(); i++){
			if(testCase.equals(result.get("TestScript").get(i)) && Integer.parseInt(currentIteration.toString())==Integer.parseInt(result.get("Iteration").get(i))){
				dataValue = result.get(colName).get(i);
				break;
			}
		}

		return dataValue;
	} catch (Exception e) {
            System.out.println(e.getMessage());   logger.error(e.getMessage());
            logger.error( "StackTrace:"+e.getStackTrace());
            
      //      TestStepLog TestStepLogObject = new TestStepLog();
       //     TestStepLogObject.Log("Unhandled Exception in reading Data", "There has been an unhandled exception "+e+" while reading data from the Test Data sheet", Report.Status.FAIL, driver, testCase, scenario,"", browser, passScreenshot, browserFolder);
		throw e;
	}

}






    public  String generateRandomString(int length, Mode mode)
    {

        StringBuilder buffer = new StringBuilder();
        String characters = "";

        switch (mode)
        {

            case ALPHA:
                characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                break;

            case ALPHANUMERIC:
                characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
                break;

            case NUMERIC:
                characters = "1234567890";
                break;
        }
        int charactersLength = characters.length();
        Random random = new Random();

        for (int i = 0; i < length; i++)
        {

            int index = random.nextInt(charactersLength);

            buffer.append(characters.charAt(index));
        }
        return buffer.toString();
    }



    public String CreateDateFolder(String homePath)
    {
        try
        {
        	File dir = new File(homePath + "/Results");
            if (!dir.exists()) dir.mkdirs();
           


            String date = "Run_" + Util.getCurrentDate();

         String   resultsFolder = homePath + "/Results/" + date;

         
     	 dir = new File(resultsFolder);
        if (!dir.exists()) dir.mkdirs();
     

            return resultsFolder;

        }
        catch (Exception e)
        {
            System.out.println(e.getMessage()); logger.error(e.getMessage());
            logger.error( "StackTrace:"+e.getStackTrace());
            
            throw e;
        }
    }


    public String CreateDirectory(String DirectoryPath, String DirectoryName)
    {
        try
        {
            String DirectoryFulPath = DirectoryPath + "/" + DirectoryName;
        	File dir = new File(DirectoryFulPath);
            if (!dir.exists()) dir.mkdirs();

            return DirectoryFulPath;

        }
        catch (Exception e)
        {
            System.out.println(e.getMessage()); logger.error(e.getMessage());
            logger.error( "StackTrace:"+e.getStackTrace());
            
            throw e;
        }
    }

    public String generateFirstName() 
    {
    	Faker faker = new Faker();
    	String firstName = faker.name().firstName();
    	
    	return firstName;
    }
    public String generateLastName() 
    {
    	Faker faker = new Faker();
    	String firstName = faker.name().lastName();
    	
    	return firstName;
    }
    
  


    public String getRandom(String value)
    {
        Random r = new Random();
        if (value.toLowerCase().contains("string"))
        {
        	
            value =generateRandomString(r.nextInt(20-5)+5, Mode.ALPHA);
        }
        if (value.toLowerCase().contains("name"))
        {
        	
            value =generateFirstName();//generateRandomString(r.nextInt(20-5)+5, Mode.ALPHA);
        }
        else if (value.toLowerCase().contains("dob"))
        {
            value = getDateOfBirth(value);
        }

        else if (value.toLowerCase().contains("ssn"))
        {
            value = GetRandomSSN();
        }
        else if (value.toLowerCase().contains("ssn_dash"))
        {
            value = GetRandomSSN("-");
        }
        else if (value.toLowerCase().contains("psuedossn"))
        {
            value = GetRandomSSN();
        }
        else if (value.toLowerCase().contains("psuedossn_dash"))
        {
            value = GetRandomSSN("-");
        }
        else if (value.toLowerCase().contains("individualid"))
        {
            value = generateRandomString(9, Mode.NUMERIC);
        }
        else if(value.toLowerCase().contains("number"))
        {
            /*ArrayList<String> values = value.Split(';').Where(x => !String.IsNullOrWhiteSpace(x)).ToList();
           */ 
            ArrayList<String> values = (ArrayList<String>) List.of(value.split(";")); 
            int length = values.size() > 1 && values != null ? Integer.parseInt(values.get(1)) : 10;
            value = generateRandomString(length, Mode.NUMERIC);
        }
        else if (value.toLowerCase().contains("alphanum"))
        {
            value = generateRandomString(30, Mode.ALPHANUMERIC);
        }
        else if(value.toLowerCase().contains("uuid") || value.toLowerCase().contains("guid"))
        {
            UUID guid = UUID.randomUUID();
            value = guid.toString();
        }

        return value;
    }

//    public String getDateOfBirth(String dataValue, String... datTimeFormat)
//    {
//       String dfformat="MM/dd/yyyy";
//       if(datTimeFormat.length==0)
//       {
//             
//             dfformat = "MM/dd/yyyy";
//       }
//        Random r = new Random();
//        String Date = "";
//        int Daterange;
//        try
//        {
//            
//            int NoOfdays = (Integer.parseInt(dataValue.split(";")[1])) * 365 + (int)((Integer.parseInt(dataValue.split(";")[1])) / 4);
//            int min =NoOfdays + 1;
//            int max =NoOfdays + 364;
//            Daterange = r.nextInt(max - min) + min;
//            
//            LocalDate Ldate = LocalDate.now();
//            Ldate=Ldate.minusDays(Daterange);
//            DateTimeFormatter format = DateTimeFormatter.ofPattern(dfformat);
//             Date = Ldate.format(format);
//            
//        }
//        catch (Exception e)
//        {
//            System.out.println(e.toString());
//            System.out.println(e.getMessage());
//            logger.error("Unable to Add Date Of Birth due to error: " + e.toString());
//            throw e;
//        }
//        return Date;
//    }

    public String getDateOfBirth(String dataValue, String... datTimeFormat)
    {
       String dfformat="MM/dd/yyyy";
       if(datTimeFormat.length==0)
       {
             
             dfformat = "MM/dd/yyyy";
       }
        Random r = new Random();
        String Date = "";
        int Daterange;
        try
        {
        	String[] rondomdob=dataValue.split(";");
            int count=rondomdob.length;
            
            	int NoOfdays = (Integer.parseInt(dataValue.split(";")[1])) * 365 + (int)((Integer.parseInt(dataValue.split(";")[1])) / 4);
                int min =NoOfdays + 1;
                int max =NoOfdays + 364;
                Daterange = r.nextInt(max - min) + min;
                
                LocalDate Ldate = LocalDate.now();
                if(count==2) 
                {
                Ldate=Ldate.minusDays(Daterange);
                DateTimeFormatter format = DateTimeFormatter.ofPattern(dfformat);
                 Date = Ldate.format(format);
                }
            
            else if(count==3) 
            {
            	NoOfdays = ((Integer.parseInt(dataValue.split(";")[1])) * 365) + ((int)((Integer.parseInt(dataValue.split(";")[1])/4 )+ ((int)((Integer.parseInt(dataValue.split(";")[2])*30)))));
            	  min =NoOfdays + 1;
                  max =NoOfdays + 29;
                 Daterange = r.nextInt(max - min) + min;
            	 Ldate=Ldate.minusDays(Daterange);
                 DateTimeFormatter format = DateTimeFormatter.ofPattern(dfformat);
                  Date = Ldate.format(format);
            }
            else if(count==4) 
            {
            NoOfdays = ((Integer.parseInt(dataValue.split(";")[1])) * 365) + ((int)((Integer.parseInt(dataValue.split(";")[1])/4 )+ ((Integer.parseInt(dataValue.split(";")[2])*30))))+ ((Integer.parseInt(dataValue.split(";")[3])*1));
                Ldate=Ldate.minusDays(NoOfdays);
                DateTimeFormatter format = DateTimeFormatter.ofPattern(dfformat);
                Date = Ldate.format(format);
            }
            
        }
        catch (Exception e)
        {
            System.out.println(e.toString());
            System.out.println(e.getMessage());
            logger.error("Unable to Add Date Of Birth due to error: " + e.toString());
            throw e;
        }
        return Date;
    }


    public String GetRandomSSN(String... delimiter)
    {
    	if(delimiter==null)
    	{
    		delimiter[0]="";
    	}
    	
        Integer iThree = GetRandomNumber(132, 921);
        Integer iTwo = GetRandomNumber(12, 83);
        Integer iFour = GetRandomNumber(1423, 9211);
        return iThree.toString() + delimiter[0] + iTwo.toString() + delimiter[0] + iFour.toString();
    }

    public String GetRandomPsuedoSSN(String... delimiter)
    {
    	if(delimiter==null)
    	{
    		delimiter[0]="";
    	}
    	
    	Integer iThree = GetRandomNumber(911, 988);
    	Integer iTwo = GetRandomNumber(12, 83);
    	Integer iFour = GetRandomNumber(1423, 9211);
        return iThree.toString() + delimiter[0] + iTwo.toString() + delimiter[0] + iFour.toString();
    }

    public int GetRandomNumber(int min, int max)
    {
        Random getrandom = new Random();
        
        return getrandom.nextInt(max - min) + min;
        
    }

    public HashMap<String, String> getTestData(String TDPath, String TestDataSheet, String scenario, String testCase, String homePath, Integer currentIteration, String browser, String passScreenshot, String browserFolder, String... DefaultTestDataFormat) throws Exception
    {

    	if(DefaultTestDataFormat==null)
    	{
    		DefaultTestDataFormat[0] = ".csv";
        
    	}
    	try
        {

    		

            ArrayList<String> TestDataSheets = (ArrayList<String>) List.of(TestDataSheet.split(";"));
            HashMap<String, String> TestData = new HashMap<String, String>();
            Random r = new Random();


            for (String TD : TestDataSheets)
            {
                String TestDataPath = TDPath + TD + DefaultTestDataFormat[0];

                POI_ReadExcel poiObject = new POI_ReadExcel();
                // TODO Auto-generated method stub




                ArrayList<String> whereClause_TestData = new ArrayList<String>();
                whereClause_TestData.add("TestScript::" + testCase.toString());
                whereClause_TestData.add("Iteration::" + currentIteration.toString());
                HashMap<String, ArrayList<String>> result = poiObject.fetchWithCondition(TestDataPath, "TestData", whereClause_TestData);



                if (result.get("Iteration").size() == 0)
                {

                    logger.error("Blank column in Test Data - There is no data in the column  for the Iteration " + currentIteration.toString() + " of test case " + testCase);
                }

                for(String key : result.keySet())
                {

					if (result.get(key).get(0).toLowerCase().trim().startsWith("random_"))
                    {
                       result.get(key).set(0,getRandom(result.get(key).get(0)));
                        Thread.sleep(500);
                        logger.info("Random Value Added in " + key + " = " +result.get(key).get(0));
                    }
                    
                    if (TestData.containsKey(key) == false)
                    {
                        TestData.put(key,result.get(key).get(0));
                    }
                    else
                    {
                        TestData.replace(key ,result.get(key).get(0));
                    }
                }

            }
            return TestData;
        }
        catch (Exception e)
        {


            System.out.println(e.getMessage()); logger.error(e.getMessage());
            logger.error( "StackTrace:"+e.getStackTrace());
            
            throw e;
        }

    }
    
    
   
    
    public static String convertFromSQLDateToJAVADate(String sqlDate) 
    {
        String CustomDate = null;
        if (sqlDate != null) 
        {
        	LocalDate tradeDate= LocalDate.parse(sqlDate, DateTimeFormatter.ofPattern("yyyy/MM/dd"));
        	CustomDate=tradeDate.format(DateTimeFormatter.ofPattern("MM/dd/yyyy")).toString();
        }
        return CustomDate;
    }
    
    public String ModifyDateFormat(String Date) 
    {
    	try 
    	{
    		Date=Date.replaceAll("-", "/");
        	LocalDate tradeDate= LocalDate.parse(Date, DateTimeFormatter.ofPattern("yyyy/MM/dd"));
        	String CustomDate=tradeDate.format(DateTimeFormatter.ofPattern("MM/dd/yyyy")).toString();
        	return CustomDate;
    	}
    	catch(Exception e) 
    	{
    		
    		throw e;
    	}
    	
    }
    
    public String ModifyDateTimeFormattodate(String Date) 
    {
    	try 
    	{
    		String[] date=Date.split(" ");
    		Date=date[0].replaceAll("-", "/");
        	LocalDate tradeDate= LocalDate.parse(Date, DateTimeFormatter.ofPattern("yyyy/MM/dd"));
        	String CustomDate=tradeDate.format(DateTimeFormatter.ofPattern("MM/dd/yyyy")).toString();
        	return CustomDate;
    	}
    	catch(Exception e) 
    	{
    		
    		throw e;
    	}
    	
    }

    public HashMap<String, String> getTestData(String TDPath, String TestDataSheet, String Module, String Environment, String currentIteration, String... DefaultTestDataFormat) throws Exception
    {

    	
    	if(DefaultTestDataFormat==null)
    	{
    	DefaultTestDataFormat[0] = ".csv";
        
    	}
    
        try
        {

            ArrayList<String> TestDataSheets = (ArrayList<String>) List.of(TestDataSheet.split(";"));
            HashMap<String, String> TestData = new HashMap<String, String>();
            Random r = new Random();


            for (String TD : TestDataSheets)
            {
                String TestDataPath = TDPath + TD + DefaultTestDataFormat;

                POI_ReadExcel poiObject = new POI_ReadExcel();
                // TODO Auto-generated method stub




                ArrayList<String> whereClause_TestData = new ArrayList<String>();
                whereClause_TestData.add("Iteration::" + currentIteration.toString());
                HashMap<String, ArrayList<String>> result = poiObject.fetchWithCondition(TestDataPath, Environment, whereClause_TestData);


                if (result.get("Iteration").size() == 0)
                {

                    logger.error("Blank column in Test Data - There is no data in the column  for the Iteration " + currentIteration.toString() + " of Environment " + Environment);
                }


                for (String key : result.keySet())
                {
                    if (result.get(key).get(0).toLowerCase().trim().startsWith("random_"))
                    {
                       result.get(key).set(0,getRandom(result.get(key).get(0)));
                        Thread.sleep(500);
                        logger.info("Random Value Added in " + key + " = " +result.get(key).get(0));
                    }
                    
                    if (TestData.containsKey(key) == false)
                    {
                        TestData.put(key,result.get(key).get(0));
                    }
                    else
                    {
                        TestData.replace(key,result.get(key).get(0));
                    }
                }


            }
            return TestData;
        }
        catch (Exception e)
        {


            System.out.println(e.getMessage()); logger.error(e.getMessage());
            logger.error( "StackTrace:"+e.getStackTrace());
            
            throw e;
        }

    }

    public String CreateResultsFolder(String homePath)
    {
        try
        {

        	File dir = new File(homePath + "/Results");
            if (!dir.exists()) dir.mkdirs();

            String date = getCurrentDate();

            String ResultsFolder_Date = homePath + "/Results/" + date;

        	dir = new File(ResultsFolder_Date);
            if (!dir.exists()) dir.mkdirs();
            
            String Time = "Run_" + getCurrentTime();

            String ResultsFolder_Time = ResultsFolder_Date + "/" + Time;


            dir = new File(ResultsFolder_Time);
            if (!dir.exists()) dir.mkdirs();
            


            return ResultsFolder_Time;

        }
        catch (Exception e)
        {
            System.out.println(e.getMessage()); logger.error(e.getMessage());
            logger.error( "StackTrace:"+e.getStackTrace());
            
            throw e;
        }
    }


    public HashMap<String, ArrayList<String>> GetScreenTCData(String ScreenName, String TestCaseName,String TestDataLocation, String TestDataMappingFileName ,String TestDataMappingSheetName)
    {

        POI_ReadExcel poiObject = new POI_ReadExcel();
        ArrayList<String> whereClause_TestData = new ArrayList<String>();
        whereClause_TestData.add("ScreenName::" + ScreenName);
        HashMap<String, ArrayList<String>> result = poiObject.fetchWithCondition(TestDataMappingFileName, TestDataMappingSheetName, whereClause_TestData);


        POI_ReadExcel poiObject2 = new POI_ReadExcel();
        ArrayList<String> whereClause_TestData2 = new ArrayList<String>();
        whereClause_TestData2.add("TestCase::" + TestCaseName);
        return poiObject2.fetchWithCondition(TestDataLocation + "/" +result.get("TestDataFileName").get(0), result.get("TestDataSheetName").get(0), whereClause_TestData2);


    }
    
    
    
    public Properties loadProperties(String Filepath) throws IOException,Exception
    {
    	

        FileInputStream propsInput = new FileInputStream(Filepath);

        Properties prop = new Properties();

        prop.load(propsInput);

       
    	return prop;
    }
    
    

}