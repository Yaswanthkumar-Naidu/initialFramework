
package UITests.TestNG.Common;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.UUID;
import java.nio.file.Path;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import ReportUtilities.Common.ReportCommon;
import ReportUtilities.Constants.HTMLReportContants;



import ReportUtilities.ExcelReport.ExcelReportGenerator;
import ReportUtilities.HTMLReport.HTMLReports;
import ReportUtilities.HTMLReport.InitializeHTMLReports;

import ReportUtilities.Model.TestCaseParam;
import ReportUtilities.Model.ExtentModel.ExtentUtilities;
import ReportUtilities.Model.ExtentModel.TestCaseDetails;
import ReportUtilities.Model.ExtentModel.TestRunDetails;
import ReportUtilities.Model.HTML.TestManager;
import ReportUtilities.UIPerfReport.ExcelReport_UIPerf;
import Reusable.PageLoadTimingInterceptor;
//import Reusable.VideoRecorder_utlity;
import InitializeScripts.InitializeTestSettings;

import TestSettings.TestRunSettings;

import io.github.bonigarcia.wdm.WebDriverManager;

import static TestSettings.TestRunSettings.runInHeadlessMode;
//import reports.extentReports.UIPerfExtentReport;

public class TestNGCommon {

	static boolean initialized = false;
	static boolean Postinitialized = false;
	static LocalDateTime StartTime=LocalDateTime.now();
	public static String TestRunId="";

	@BeforeSuite
	public void TestRunSetUp() throws Exception
	{
		System.out.println("Executing BeforeSuite setup...");
		Path currentRelativePath = Paths.get("");
		String PrjPath=currentRelativePath.toAbsolutePath().toString();



		InitializeTestSettings initObj = new InitializeTestSettings();
		initObj.LoadConfigData(PrjPath);


		CommonImplementation commimplementation = new CommonImplementation();
		commimplementation.LoadLoginData();

		ReportUtilities.ExtentReport.ExtentReport startliveextentreport = new ReportUtilities.ExtentReport.ExtentReport();
		startliveextentreport.StartReport(TestRunSettings.ResultsPath,TestRunSettings.Environment);


		InitializeHTMLReports initializeHTMLReports = new InitializeHTMLReports();
		initializeHTMLReports.initHTMLReports(PrjPath,TestRunSettings.ResultsPath);
		HTMLReports htmlReports= new HTMLReports();

		htmlReports.CreateTCHTMLLiveSummary();

		//TestRun Details
		UUID TestRunUUId= UUID.randomUUID();
		ReportCommon rcommon= new ReportCommon();
		String startTime =rcommon.ConvertLocalDateTimetoSQLDateTime(StartTime);


	}


	public void EndTestCase(TestCaseParam testCaseParam){

		ExtentUtilities extentUtilities = new ExtentUtilities();
		extentUtilities.endTestCase(testCaseParam.TestCaseName, testCaseParam.ModuleName, testCaseParam.Browser);


		TestManager.updateTestCaseStatus(testCaseParam.TestCaseName, testCaseParam.ModuleName, testCaseParam.Browser,HTMLReportContants.HTMLTCStatus.Passed);
	}

	@AfterSuite
	public void TestRunTearDown() throws Exception
	{
		// Generate PDF Report
		try {
			ReportUtilities.ExtentReport.ExtentReport extentReport = new ReportUtilities.ExtentReport.ExtentReport();
			extentReport.CreateExtentReport_Model(TestRunSettings.ResultsPath, TestRunDetails.getTestCaseRepository(), "Test", "Test", "Test");
		} catch (Exception e) {
			System.out.println("Failed to generate the extent test results");
			System.out.println(e.getMessage());
			e.printStackTrace();
		}


		//VideoRecorder_utlity.stopRecord();
		//recorder.stop();
//		if (!initialized) {
//			initialized = true;
//			try {
//
//				LocalDateTime EndTime = LocalDateTime.now();
//				ReportCommon rcommon= new ReportCommon();
//				String endTime = rcommon.ConvertLocalDateTimetoSQLDateTime(EndTime);
//				String Duration=rcommon.getDuration(StartTime, EndTime);
//
//				System.out.println("TestRunID Updated successfully");
//			}catch(Exception e)
//			{
//				System.out.println("Failed to update TestRunID");
//				System.out.println(e.getMessage());
//				System.out.println(e.getStackTrace());
//			}
//
//			try
//			{
//				if(TestRunSettings.CaptureUIPerformance.equalsIgnoreCase("Yes"))
//				{
//					ExcelReport_UIPerf uiperfreport=new ExcelReport_UIPerf();
//					uiperfreport.writeDataToExcel(TestRunSettings.ResultsPath+TestRunSettings.UIPerfFileName);
//				}
//
//			}
//			catch(Exception e)
//			{
//				System.out.println("Unable to generate UI Perf report");
//			}

			// Extent report live
			try {

				ReportUtilities.ExtentReport.ExtentReport extentReportlive = new ReportUtilities.ExtentReport.ExtentReport();
				extentReportlive.EndReport();
			}
			catch(Exception e)
			{
				System.out.println("Failed to generate the Live Results");
				System.out.println(e.getMessage());
				System.out.println(e.getStackTrace());
			}




			//Calculate Results
			try
			{
				ReportCommon reportcommon=new ReportCommon();
				reportcommon.CalculateTestCaseResults(TestRunDetails.getTestCaseRepository());
				reportcommon.CalculateModuleResults();
				reportcommon.CalculateBrowserResults();
			}
			catch(Exception e)
			{
				System.out.println("Failed to compute the Test Case details");
				System.out.println(e.getMessage());
				System.out.println(e.getStackTrace());

			}


			//Extent Report
			try
			{
				ReportUtilities.ExtentReport.ExtentReport extentReport = new ReportUtilities.ExtentReport.ExtentReport();
				extentReport.CreateExtentReport_Model(TestRunSettings.ResultsPath,TestRunDetails.getTestCaseRepository(),"Test","Test","Test");
			}
			catch(Exception e)
			{
				System.out.println("Failed to generate the extent test results");
				System.out.println(e.getMessage());
				System.out.println(e.getStackTrace());

			}


			//ExtentReport By Category

			try
			{
				ReportUtilities.ExtentReport.ExtentReport extentReport = new ReportUtilities.ExtentReport.ExtentReport();
				extentReport.CreateExtentReport_Category(TestRunSettings.ResultsPath,TestRunDetails.getTestCaseRepository(),"Test","Test","Test");
			}
			catch(Exception e)
			{
				System.out.println("Failed to generate the extent test results");
				System.out.println(e.getMessage());
				System.out.println(e.getStackTrace());

			}


////			//Generate Excel Reports
////			try
////			{
////				ExcelReportGenerator excelreport = new ExcelReportGenerator();
////				excelreport.GenerateExcelReport(TestRunDetails.getTestCaseRepository(),TestRunSettings.ResultsPath+ TestRunSettings.ExcelFilepath);
////			}
////			catch(Exception e)
////			{
////				System.out.println("Failed to generate the Excel Test Results");
////				System.out.println(e.getMessage());
////				System.out.println(e.getStackTrace());
////
////			}
////
//
			//Generate HTML Reports
			try
			{
				HTMLReports htmlReport = new HTMLReports();
				htmlReport.GenerateReport(TestRunSettings.ResultsPath);
			}
			catch(Exception e)
			{
				System.out.println("Failed to generate the Excel Test Results");
				System.out.println(e.getMessage());
				System.out.println(e.getStackTrace());

			}

//		}
//
	}

	public void InitializeTestCase(TestCaseParam testCaseParam)
	{

		ExtentUtilities extentUtilities = new ExtentUtilities();
////
////		if (extentUtilities.getTestCaseID(testCaseParam.TestCaseName, testCaseParam.ModuleName, testCaseParam.Browser) == null)
////		{
//		// Initialize the test case in Extent Report
		extentUtilities.InitializeNewTestCase(testCaseParam.TestCaseName, testCaseParam.TestCaseDescription, testCaseParam.ModuleName,testCaseParam.TestCaseCategory,testCaseParam.CaseNumber,testCaseParam.ApplicationNumber, testCaseParam.Browser);
//		}
//		else
//		{
//		}

	}


	public void publishTestCaseResults(TestCaseParam testCaseParam) {
		try {
			TestCaseDetails testCaseDetails = new TestCaseDetails();
			List<HashMap<UUID, TestCaseDetails>> testCaseRepository = TestRunDetails.getTestCaseRepository();

			System.out.println("Test Case Repository Size: " + testCaseRepository.size());

			outer: for (HashMap<UUID, TestCaseDetails> testCaseMap : testCaseRepository) {
				System.out.println("Processing testCaseMap of size: " + testCaseMap.size());

				for (TestCaseDetails TCDetails : testCaseMap.values()) {
					System.out.println("Checking TestCaseDetails: " + TCDetails.TestCaseName);

			/*		if ((TCDetails.TestCaseName.equals(testCaseParam.TestCaseName)) &&
							(TCDetails.Module.equals(testCaseParam.ModuleName)) &&
							(TCDetails.Browser.equals(testCaseParam.Browser)) &&
							(TCDetails.Iteration == testCaseParam.Iteration)) {

						testCaseDetails = TCDetails;
						break outer;
					}*/
				}
			}

//			try {
//				ExcelReportGenerator excelReportGenerator = new ExcelReportGenerator();
//				excelReportGenerator.GenerateExcelReportTestCase(
//						testCaseDetails,
//						TestRunSettings.TempExcelTestCaseResults + "/" + testCaseDetails.TestCaseName + ".xlsx"
//				);
//			} catch (Exception ex) {
//				System.out.println("Failed to get the Test Case Results for excel");
//				System.out.println(ex.getMessage());
//				ex.printStackTrace();
//			}
		} catch (Exception e) {
			System.out.println("Failed to get the Test Case Details");
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}

	public WebDriver InitializeDriver()
	{

		WebDriverManager.chromedriver().setup();
		//System.setProperty("webdriver.chrome.driver", "C:\\SeleniumDrivers\\chrome-win64\\chrome_proxy.exe");
		ChromeOptions options= new ChromeOptions();
		options.setAcceptInsecureCerts(true);

		// Force headless mode in CI environment
		if (System.getenv("CI") != null || runInHeadlessMode.equalsIgnoreCase("Yes")) {
			options.addArguments("--headless");
		}

		options.addArguments("start-maximized"); // open Browser in maximized mode
		//options.addArguments("--start-fullscreen");
		//options.addArguments("--incognito");
		options.addArguments("disable-infobars"); // disabling infobars
		options.addArguments("--disable-extensions"); // disabling extensions
		options.addArguments("--disable-gpu"); // applicable to windows os only
		options.addArguments("--disable-dev-shm-usage"); // overcome limited resource problems
		options.addArguments("--no-sandbox"); // Bypass OS security model
		options.addArguments("--use-fake-ui-for-media-stream=1");

		WebDriver driver= new ChromeDriver(options);
		driver.manage().deleteAllCookies();
		// Further actions based on runInHeadlessMode setting
		if (runInHeadlessMode.equalsIgnoreCase("Yes") || System.getenv("CI") != null) {
			PageLoadTimingInterceptor PTI = new PageLoadTimingInterceptor(driver);
			driver = PTI.createProxy(driver);
		}

		return driver;

	}



	public WebDriver InitializeDriverIncognito()
	{
		//System.setProperty("webdriver.chrome.driver", "C:\\SeleniumDrivers\\chromedriver.exe");
		ChromeOptions options= new ChromeOptions();
		options.setAcceptInsecureCerts(true);
		options.addArguments("headless");
		options.addArguments("start-maximized"); // open Browser in maximized mode
		options.addArguments("--start-fullscreen");
		options.addArguments("--incognito");
		options.addArguments("disable-infobars"); // disabling infobars
		options.addArguments("--disable-extensions"); // disabling extensions
		options.addArguments("--disable-gpu"); // applicable to windows os only
		options.addArguments("--disable-dev-shm-usage"); // overcome limited resource problems
		options.addArguments("--no-sandbox"); // Bypass OS security model
		WebDriver driver= new ChromeDriver(options);
		driver.manage().deleteAllCookies();

		return driver;
	}

	public WebDriver InitializeAndroidDriver() throws IOException
	{
		DesiredCapabilities capabilities = new DesiredCapabilities();

		capabilities.setCapability("chromedriverExecutable","C:/SeleniumDrivers/chromedriver.exe");

		capabilities.setCapability("deviceName", "a52q");

		capabilities.setCapability("platformName", "Android");

		capabilities.setCapability("platformVersion", "12");

		capabilities.setCapability("browserName", "chrome");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--user-agent=Chrome/99.0.4844.73");
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		String url = "http://127.0.0.1:4723/wd/hub";
		WebDriver driver = new RemoteWebDriver(new java.net.URL("http://127.0.0.1:4723/wd/hub"),capabilities);
		//WebDriver driver = new AndroidDriver<>(new URL(url), capabilities);

		return driver;
	}

	public WebDriver InitializeEdgeDriver()
	{
		System.setProperty("webdriver.edge.driver", "C:/SeleniumDrivers/msedgedriver.exe");
		WebDriver driver= new EdgeDriver();
		return driver;
	}

	public void QuitDriver(WebDriver driver)
	{
		try
		{
			driver.quit();
		}
		catch(Exception e)
		{

		}
	}


}





