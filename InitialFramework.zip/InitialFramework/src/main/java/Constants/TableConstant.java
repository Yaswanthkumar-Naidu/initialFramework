package Constants;

public class TableConstant 
{
	
	//PRIMARY APPLICANT ADDRESS INFO--------------------------------------
	public static final int ApplicantAddressInfo_FromDate = 1;
	public static final int ApplicantAddressInfo_Address = 2;
	public static final int ApplicantAddressInfo_Country = 3;
	
	//INDIVIDUAL ADDRESS INFO---------------------------------------------
	public static final int IndividualAddressInfo_Name = 1;
	public static final int IndividualAddressInfo_AddressType = 2;
	public static final int IndividualAddressInfo_Address = 3;
	public static final int IndividualAddressInfo_Country = 4;
	
	
	//LIVING ARRANGEMENT---------------------------------------------------
	public static final int LivingArrangement_StartDate = 1;
	public static final int LivingArrangement_LivingArrangementType = 2;
	public static final int LivingArrangement_provider = 3;
	
	
	//RESIDENCY-------------------------------------------------------------
	public static final int Residency_StartDate = 1;
	public static final int Residency_State = 2;
	public static final int Residency_IntendstoRemain = 3;
	
	
	//PREGNANCY INFORMATION------------------------------------------------
	public static final int Pregnancy_Name = 1;
	public static final int Pregnancy_DueDate = 2;
	public static final int Pregnancy_WIC = 3;
	public static final int Pregnancy_NumberofBirth = 4;
	
	
	//DISABILITY INFORMATION------------------------------------------------
	public static final int Disability_Name = 1;
	public static final int Disability_Type = 2;
	public static final int Disability_StartDate = 3;
	
	
	//LIQUID RESOURCES-------------------------------------------------------
	public static final int LiquidResources_Owner = 1;
	public static final int LiquidResource_Type = 2;
	public static final int LiquidResource_Amount = 3;
	public static final int LiquidResource_CurrentlyAccessible = 4;
	public static final int LiquidResource_DateAquired = 5;
	
	
	//EARNED INCOME VERIFICATION----------------------------------------------
	public static final int EarnedIncomeVerification_IncomeFrom = 1;
	public static final int EarnedIncomeVerification_Anticipated = 2;
	
	//SELFEMPLOYMENT INCOME VERIFICATION----------------------------------------------
		public static final int SelfemploymentIncomeVerification_IncomeFrom = 1;
		public static final int SelfemploymentIncomeVerification_VerificationType = 2;
	
	//CHILD SUPPORT ALIMONY EXPENSE--------------------------------------------
	public static final int ChildSupportAlimonyexpense_Person = 1;
	public static final int ChildSupportAlimonyexpense_ExpenseType = 2;
	public static final int ChildSupportAlimonyexpense_StartDate = 3;
	
	//MEDICAL EXPENSE-----------------------------------------------------------
	public static final int MedicalExpense_Person = 1;
	public static final int MedicalExpense_Type = 2;
	public static final int MedicalExpense_AppliesTo = 3;
	public static final int MedicalExpense_Amount = 4;
	public static final int MedicalExpense_StartDate = 5;
	
	//Utility Expense — SUA/BUA/Telephone---------------------------------------
	public static final int UtilityExpenseSUA_Person = 1;
	public static final int UtilityExpenseSUA_Type = 2;
	public static final int UtilityExpenseSUA_StartDate = 3;
	
	//DISCONTINUED SSI-----------------------------------------------------------
	public static final int DiscontinuedSSI_Name = 1;
	public static final int DiscontinuedSSI_Type = 2;
	
	//MCO PRE SELECTION-----------------------------------------------------------
	public static final int Mcopreselection_Name = 1;
	public static final int Mcopreselection_Preferences = 3;
	
	
	//RESOURCE SUMMARY-------------------------------------------------------------
	
	//liquid resources
	public static final int ResourceSummaryLiquidResource_Owner = 1;
	public static final int ResourceSummaryLiquidResource_Type = 2;
	public static final int ResourceSummaryLiquidResource_Amount = 3;
	public static final int ResourceSummaryLiquidResource_CurrentlyAccessible = 4;
	public static final int ResourceSummaryLiquidResource_DateAquired = 5;
	
	//INCOME SUMMARY--------------------------------------------------------------
	
	//Earned Income
	public static final int IncomeSummaryEarnedIncome_Name = 1;
	public static final int IncomeSummaryEarnedIncome_Type = 2;
	public static final int IncomeSummaryEarnedIncome_Employer = 3;
	public static final int IncomeSummaryEarnedIncome_Amount = 4;
	
	//Unearned Income
	public static final int IncomeSummaryUnEarnedIncome_Name = 1;
	public static final int IncomeSummaryUnEarnedIncome_Type = 2;
	public static final int IncomeSummaryUnEarnedIncome_Amount = 3;
		
	//Self Employment Income
	public static final int IncomeSummarySelfEmployemntIncome_Name = 1;
	public static final int IncomeSummarySelfEmployemntIncome_Type = 2;
	public static final int IncomeSummarySelfEmployemntIncome_Verification = 4;
	//EXPENSE SUMMARY--------------------------------------------------------------
	
	//CHILD SUPPORT ALIMONY EXPENSE
	public static final int ExpenseSummaryChildSupport_Person = 1;
	public static final int ExpenseSummaryChildSupport_Type = 2;
	public static final int ExpenseSummaryChildSupport_StartDate = 5;
	
	//Medical Expense
	public static final int ExpenseSummaryMedical_Person = 1;
	public static final int ExpenseSummaryMedical_Type = 2;
	public static final int ExpenseSummaryMedical_AppliesTo = 3;
	public static final int ExpenseSummaryMedical_Amount = 4;
	public static final int ExpenseSummaryMedical_StartDate = 5;
	
	//Utility Expense — SUA/BUA/Telephone
	public static final int ExpenseSummarySUA_Person = 1;
	public static final int ExpenseSummarySUA_Type = 2;
	public static final int ExpenseSummarySUA_StartDate = 3;		
}
