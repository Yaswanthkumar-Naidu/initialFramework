package Constants;

public class ModuleConstants_CS {
    public static String Login = "Login";
    public static String Enrollment = "Enrollment";
    public static String Intake = "Intake";
    public static final String IntakeCase = "Intake Case";
    public static final String Locate = "Locate";
    public static final String Accounts = "Accounts";
    public static final String Cases = "Cases";
    public static final String CasesNodes = "Cases Nodes";
    public static final String Contacts = "Contacts";
    public static final String ContactsNodes = "Contacts Nodes";

}
