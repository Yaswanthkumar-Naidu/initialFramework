package InitializeScripts;

import CommonUtilities.Utilities.Util;
import Constants.PrjConstants;
import ReportUtilities.Constants.ReportContants;
import TestSettings.TestRunSettings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.Properties;

import static org.aspectj.weaver.tools.cache.SimpleCacheFactory.path;

public class InitializeTestSettings
{
	
    private static final Logger logger =LoggerFactory.getLogger(InitializeTestSettings.class.getName());


    Properties prop=new Properties();

	Util util = new Util();

	// Get the current working directory
	static String projectRoot = System.getProperty("user.dir");

	// Function to get the absolute path based on the project root and the relative path
	public static String getAbsolutePath(String relativePath) {
		return Paths.get(projectRoot, relativePath).toAbsolutePath().toString();
	//	return Paths.get(path).toAbsolutePath().toString();
	}

	public void LoadConfigData(String PrjPath) throws Exception {
		try {
			// Construct the file path in a cross-platform manner
			String configFilePath = Paths.get(PrjPath, "config.properties").toString();
			File configFile = new File(configFilePath);

			if (!configFile.exists()) {
				throw new IOException("Config file not found: " + configFile.getAbsolutePath());
			}

			prop = new Properties();
			try (FileInputStream fis = new FileInputStream(configFile)) {
				prop.load(fis);
			}

			TestRunSettings.HomePath = PrjPath;
			TestRunSettings.URL = prop.getProperty("URL");
			TestRunSettings.ProjectName = prop.getProperty("ProjectName");
			TestRunSettings.Release = prop.getProperty("Release");

			TestRunSettings.Environment = prop.getProperty("Environment").toUpperCase().trim();
			TestRunSettings.TestRunName = prop.getProperty("TestRunName");
			TestRunSettings.ExecutedBy = prop.getProperty("ExecutedBy");
			TestRunSettings.Browser = prop.getProperty("Browser");

			if (prop.getProperty("CustomBrowserLocation").equalsIgnoreCase("Yes")) {
				TestRunSettings.BrowserLocation = prop.getProperty("BrowserLocation");
			} else {
				TestRunSettings.BrowserLocation = TestRunSettings.HomePath + "/Drivers";
			}

			TestRunSettings.MaximizedMode = prop.getProperty("MaximizedMode").equalsIgnoreCase("Yes");
			TestRunSettings.isSnapshotForAllPass = prop.getProperty("SnapshotForAllPass").equalsIgnoreCase("Yes");
			TestRunSettings.isFullPageScreenshot = prop.getProperty("FullPageScreenshot").equalsIgnoreCase("Yes");

			TestRunSettings.PageLoadTimeout = Integer.parseInt(prop.getProperty("PageLoadTimeout"));
			TestRunSettings.ElementTimeout = Integer.parseInt(prop.getProperty("ElementTimeout"));
			TestRunSettings.ElementTimeoutLongWait = Integer.parseInt(prop.getProperty("ElementTimeoutLongWait"));

			//run in headless mode
			TestRunSettings.runInHeadlessMode = prop.getProperty("runInHeadlessMode");
			// Set the Artifacts Path and other paths dynamically
			TestRunSettings.ArtifactsPath = getAbsolutePath(prop.getProperty("ArtifactsPath"));
			TestRunSettings.TestDataPath = getAbsolutePath(prop.getProperty("ArtifactsPath"));
			TestRunSettings.TestDataMappingFileName = getAbsolutePath(prop.getProperty("TestDataMappingFileName"));
			TestRunSettings.TestDataMappingSheetName_CS = prop.getProperty("TestDataMappingSheetName_CS");
			TestRunSettings.TestDataLocation_CS = getAbsolutePath(prop.getProperty("TestDataLocation_CS"));
			TestRunSettings.UploadDocumentPath = getAbsolutePath(prop.getProperty("UploadDocumentPath"));

			// Print the paths to verify
			System.out.println("ArtifactsPath: " + TestRunSettings.ArtifactsPath);
			System.out.println("TestDataPath: " + TestRunSettings.TestDataPath);
			System.out.println("TestDataMappingFileName: " + TestRunSettings.TestDataMappingFileName);
			System.out.println("TestDataLocation_CS: " + TestRunSettings.TestDataLocation_CS);
			System.out.println("UploadDocumentPath: " + TestRunSettings.UploadDocumentPath);

			TestRunSettings.ConfigLocation = getAbsolutePath(prop.getProperty("ConfigLocation"));
			TestRunSettings.ApplicationCredentialsFileName = getAbsolutePath(prop.getProperty("ApplicationCredentialsFileName"));
			TestRunSettings.ApplicationCredentialsSheetName = prop.getProperty("ApplicationCredentialsSheetName");

			TestRunSettings.ResultsPath = getResultsPath();

			TestRunSettings.isParallelExecution = prop.getProperty("ParallelExecution").equalsIgnoreCase("Yes");
			if (TestRunSettings.isParallelExecution) {
				TestRunSettings.ParallelNodesCount = Integer.parseInt(prop.getProperty("ParallelNodes"));
				TestRunSettings.ParallelExecutionConfig = prop.getProperty("ParallelExecutionConfig");
				TestRunSettings.ParallelNodeSheetAssociation = prop.getProperty("ParallelNodeSheetAssociation");
			}

			TestRunSettings.LoadDriverOptions = loadDriverDetails();
			TestRunSettings.ChromeConfig = prop.getProperty("ChromeConfig");
			TestRunSettings.FireFoxConfig = prop.getProperty("FireFoxConfig");
			TestRunSettings.IEConfig = prop.getProperty("IEConfig");
			TestRunSettings.EdgeConfig = prop.getProperty("EdgeConfig");
			TestRunSettings.OperaConfig = prop.getProperty("OperaConfig");
			TestRunSettings.CloudConfig = prop.getProperty("CloudConfig");
			TestRunSettings.AndroidConfig = prop.getProperty("AndroidConfig");
			TestRunSettings.IOSConfig = prop.getProperty("IOSConfig");

			TestRunSettings.FireFoxLocation = prop.getProperty("FireFoxLocation");
			TestRunSettings.IEDriverLocation = TestRunSettings.HomePath + prop.getProperty("IEDriverLocation");
			TestRunSettings.OperaLocation = TestRunSettings.HomePath + prop.getProperty("IEDriverLocation");

			TestRunSettings.UploadDocumentPath = TestRunSettings.ArtifactsPath + prop.getProperty("UploadDocumentLocation");

			TestRunSettings.InterfaceSheetDetails = prop.getProperty("InterfaceSheetDetails");
			TestRunSettings.ExcelSheetExtension = prop.getProperty("ExcelSheetExtension");
			TestRunSettings.XMLExtension = prop.getProperty("XMLExtension");
			TestRunSettings.JSONExtension = prop.getProperty("JSONExtension");
			TestRunSettings.CommonMockSheetName = prop.getProperty("CommonMockSheetName");
			TestRunSettings.UseCommonMockSheet = prop.getProperty("UseCommonMockSheet");
			TestRunSettings.MockTemplateLocation = TestRunSettings.ArtifactsPath + prop.getProperty("MockTemplateLocation");

			TestRunSettings.HeaderRepositorySheetName = prop.getProperty("HeaderRepositorySheetName");
			TestRunSettings.DefaultServiceTimeout = Integer.parseInt(prop.getProperty("DefaultServiceTimeout"));

			TestRunSettings.CaptureTimeTravelDate = prop.getProperty("CaptureTimeTravelDate");
			TestRunSettings.UBTT = prop.getProperty("UBTT");
			TestRunSettings.AccountNumber = prop.getProperty("AccountNumber");

			ReportContants reportConstants = new ReportContants(TestRunSettings.ResultsPath, TestRunSettings.isSnapshotForAllPass, TestRunSettings.isFullPageScreenshot);

		} catch (Exception e) {
			logger.info("Failed to Initialize the Test Run Settings");
			System.out.println("Failed to Initialize the Test Run Settings");
			System.out.println(e.getMessage());
			System.out.println("StackTrace:" + e.getStackTrace());
			logger.info(e.getMessage());
			logger.info("StackTrace:" + e.getStackTrace());
			throw new Exception("Failed to Initialize the Test Run Settings");
		}
	}
	
//	public void LoadConfigData(String PrjPath) throws Exception
//	{
//		try
//		{
//
//		 prop=util.loadProperties(PrjPath+PrjConstants.ConfigFile);
//			TestRunSettings.HomePath = PrjPath;
//
//
//			TestRunSettings.URL = prop.getProperty("URL");
//			TestRunSettings.ProjectName = prop.getProperty("ProjectName");
//			TestRunSettings.Release = prop.getProperty("Release");
//
//			TestRunSettings.Environment = prop.getProperty("Environment").toUpperCase().trim();
//			TestRunSettings.TestRunName = prop.getProperty("TestRunName");
//			TestRunSettings.ExecutedBy = prop.getProperty("ExecutedBy");
//			TestRunSettings.Browser = prop.getProperty("Browser");
//
//			if (prop.getProperty("CustomBrowserLocation").equalsIgnoreCase("Yes"))
//			{
//				TestRunSettings.BrowserLocation = prop.getProperty("BrowserLocation");
//			}
//			else
//			{
//				TestRunSettings.BrowserLocation = TestRunSettings.HomePath + "\\Drivers";
//
//			}
//
//			if (prop.getProperty("MaximizedMode").equalsIgnoreCase("Yes"))
//			{
//				TestRunSettings.MaximizedMode = true;
//			}
//			if (prop.getProperty("SnapshotForAllPass").equalsIgnoreCase("Yes"))
//			{
//				TestRunSettings.isSnapshotForAllPass = true;
//			}
//			else
//			{
//				TestRunSettings.isSnapshotForAllPass = false;
//			}
//
//			if (prop.getProperty("FullPageScreenshot").equalsIgnoreCase("Yes"))
//			{
//				TestRunSettings.isFullPageScreenshot = true;
//			}
//			else
//			{
//				TestRunSettings.isFullPageScreenshot = false;
//			}
//
//			TestRunSettings.PageLoadTimeout = Integer.parseInt(prop.getProperty("PageLoadTimeout").toString());
//			TestRunSettings.ElementTimeout = Integer.parseInt(prop.getProperty("ElementTimeout").toString());
//			TestRunSettings.ElementTimeoutLongWait = Integer.parseInt(prop.getProperty("ElementTimeoutLongWait").toString());
//
//			// Set the Artifacts Path and other paths dynamically
//			TestRunSettings.ArtifactsPath = getAbsolutePath(prop.getProperty("ArtifactsPath"));
//			TestRunSettings.TestDataPath = getAbsolutePath(prop.getProperty("ArtifactsPath"));
//			TestRunSettings.TestDataMappingFileName = getAbsolutePath(prop.getProperty("TestDataMappingFileName"));
//			TestRunSettings.TestDataMappingSheetName_CS = prop.getProperty("TestDataMappingSheetName_CS");
//			TestRunSettings.TestDataLocation_CS = getAbsolutePath(prop.getProperty("TestDataLocation_CS"));
//			TestRunSettings.UploadDocumentPath = getAbsolutePath(prop.getProperty("UploadDocumentPath"));
//
//			// Print the paths to verify
//			System.out.println("ArtifactsPath: " + TestRunSettings.ArtifactsPath);
//			System.out.println("TestDataPath: " + TestRunSettings.TestDataPath);
//			System.out.println("TestDataMappingFileName: " + TestRunSettings.TestDataMappingFileName);
//			System.out.println("TestDataLocation_CS: " + TestRunSettings.TestDataLocation_CS);
//			System.out.println("UploadDocumentPath: " + TestRunSettings.UploadDocumentPath);
//
//			TestRunSettings.ConfigLocation = getAbsolutePath(prop.getProperty("ConfigLocation"));
//			// Set the Application Credentials path
//			TestRunSettings.ApplicationCredentialsFileName = getAbsolutePath(prop.getProperty("ApplicationCredentialsFileName"));
//			TestRunSettings.ApplicationCredentialsSheetName = prop.getProperty("ApplicationCredentialsSheetName");
//
//			//Set Results Location
//			TestRunSettings.ResultsPath = getResultsPath();
//		//	TestRunSettings.TempExcelTestCaseResults = getTempExcelPath(TestRunSettings.ResultsPath);
//		//	TestRunSettings.TempXMLTestCaseResults = getTempXMLPath(TestRunSettings.ResultsPath);
//		//	TestRunSettings.TempJSONTestCaseResults = getTempJSONPath(TestRunSettings.ResultsPath);
//
//
//			//Parallel Execution Setup
//			if (prop.getProperty("ParallelExecution").equalsIgnoreCase("Yes"))
//			{
//				TestRunSettings.isParallelExecution = true;
//				TestRunSettings.ParallelNodesCount = Integer.parseInt(prop.getProperty("ParallelNodes").toString());
//				TestRunSettings.ParallelExecutionConfig = prop.getProperty("ParallelExecutionConfig");
//				TestRunSettings.ParallelNodeSheetAssociation = prop.getProperty("ParallelNodeSheetAssociation");
//
//			}
//
//
//
//			//Setup Driver Config
//			TestRunSettings.LoadDriverOptions = loadDriverDetails();
//			TestRunSettings.ChromeConfig = prop.getProperty("ChromeConfig");
//			TestRunSettings.FireFoxConfig = prop.getProperty("FireFoxConfig");
//			TestRunSettings.IEConfig = prop.getProperty("IEConfig");
//			TestRunSettings.EdgeConfig = prop.getProperty("EdgeConfig");
//			TestRunSettings.OperaConfig = prop.getProperty("OperaConfig");
//			TestRunSettings.CloudConfig = prop.getProperty("CloudConfig");
//			TestRunSettings.AndroidConfig = prop.getProperty("AndroidConfig");
//			TestRunSettings.IOSConfig = prop.getProperty("IOSConfig");
//
//
//
//			//Browser Location in OS
//			TestRunSettings.FireFoxLocation = prop.getProperty("FireFoxLocation");
//			TestRunSettings.IEDriverLocation = TestRunSettings.HomePath + prop.getProperty("IEDriverLocation");
//			TestRunSettings.OperaLocation = TestRunSettings.HomePath + prop.getProperty("IEDriverLocation");
//
//
//			TestRunSettings.UploadDocumentPath = TestRunSettings.ArtifactsPath + prop.getProperty("UploadDocumentLocation");
//
//
//			TestRunSettings.InterfaceSheetDetails = prop.getProperty("InterfaceSheetDetails");
//
//			TestRunSettings.ExcelSheetExtension = prop.getProperty("ExcelSheetExtension");
//			TestRunSettings.XMLExtension = prop.getProperty("XMLExtension");
//			TestRunSettings.JSONExtension = prop.getProperty("JSONExtension");
//			TestRunSettings.CommonMockSheetName = prop.getProperty("CommonMockSheetName");
//			TestRunSettings.UseCommonMockSheet = prop.getProperty("UseCommonMockSheet");
//			TestRunSettings.MockTemplateLocation = TestRunSettings.ArtifactsPath + prop.getProperty("MockTemplateLocation");
//
//			TestRunSettings.HeaderRepositorySheetName = prop.getProperty("HeaderRepositorySheetName");
//		//	TestRunSettings.MockSheetName = GetMockSheetName(TestRunSettings.UseCommonMockSheet, TestRunSettings.CommonMockSheetName, TestRunSettings.Environment);
//		//	TestRunSettings.AddReportToDB = AddReportToDB(prop.getProperty("AddReportToDataBase"));
//			TestRunSettings.DefaultServiceTimeout = Integer.parseInt(prop.getProperty("DefaultServiceTimeout"));
//
//			TestRunSettings.CaptureTimeTravelDate=prop.getProperty("CaptureTimeTravelDate");
//			TestRunSettings.UBTT=prop.getProperty("UBTT");
//			TestRunSettings.AccountNumber=prop.getProperty("AccountNumber");
//
//
//		//	TestRunSettings.RequestFolderPath = prop.getProperty("RequestFolderName");
//		//	TestRunSettings.ResponseFolderPath = prop.getProperty("ResponseFolderName");
//
//			//Excel Reports
//		//	TestRunSettings.GenerateExcelReport = GenerateExcelFile(prop.getProperty("GenerateExcelReports"));
//		//	TestRunSettings.ExcelFileName = prop.getProperty("ExcelReportFileName");
//	//		TestRunSettings.ExcelFilepath=TestRunSettings.ResultsFolderPath+"\\"+ TestRunSettings.ExcelFileName + TestRunSettings.ExcelSheetExtension;
//
//			//UIPerf Reports
//	//		TestRunSettings.UIPerfFileName=prop.getProperty("UIPerfFileName");
//	//		TestRunSettings.CaptureUIPerformance=prop.getProperty("CaptureUIPerformance");
//
//
//
//
//
//
//			ReportContants reportConstants = new ReportContants(TestRunSettings.ResultsPath,TestRunSettings.isSnapshotForAllPass,TestRunSettings.isFullPageScreenshot);
//
//
//
//		}
//		catch (Exception e)
//		{
//			logger.info("Failed to Initialize the Test Run Settings");
//			System.out.println("Failed to Initialize the Test Run Settings");
//			System.out.println(e.getMessage());
//			System.out.println("StackTrace:"+e.getStackTrace());
//			logger.info(e.getMessage());
//			logger.info("StackTrace:"+e.getStackTrace());
//			throw new Exception("Failed to Initialize the Test Run Settings");
//
//		}
//
//	}





	/// <summary>
	/// This method will return true if the Excel Report Generation is set to 'YES' in config file
	///Author: Jigesh Shah
	/// </summary>
	/// <param name="strGenerateExcelReport">Yes/No based on the Excel Report Generation</param>
	/// <returns>true if Value is set to 'YES'</returns>
//	boolean GenerateExcelFile(String strGenerateExcelReport)
//	{
//
//		if (strGenerateExcelReport.toUpperCase().trim().equals("YES"))
//		{
//			return true;
//		}
//		else
//			return false;
//	}

	/// <summary>
	/// This method will return true if the Excel Report Generation is set to 'YES' in config file
	/// Author : Jigesh Shah
	/// </summary>
	/// <param name="strEmailGeneration">YES/NO</param>
	/// <returns>true if Value is set to 'YES'</returns>
//	boolean SendEmail(String strEmailGeneration)
//	{
//
//		if (strEmailGeneration.toUpperCase().trim().equals("YES"))
//		{
//			return true;
//		}
//		else
//			return false;
//	}


	/// <summary>
	/// This method will return true if the Attached Files for Passed Test Cases is set to 'YES' in config file
	/// Author: Jigesh Shah
	/// </summary>
	/// <param name="AttachFilePassedCases">Yes/No</param>
//	/// <returns>true if Value is set to 'YES'</returns>
//	boolean AttachFileForPassedTestCases(String AttachFilePassedCases)
//	{
//
//		if (AttachFilePassedCases.toUpperCase().trim().equals("YES"))
//		{
//			return true;
//		}
//		else
//			return false;
//	}

	/// <summary>
	/// This method will return true if External Mock Files needs to be placed on Mock Servers
	/// Author: Jigesh Shah
	/// </summary>
	/// <param name="UseCommonMockSheet">Yes/No</param>
	/// <param name="CommonMockSheetName">Mock Sheet Name</param>
	/// <param name="Environment">Environment Name</param>
	/// <returns></returns>
//	String GetMockSheetName(String UseCommonMockSheet, String CommonMockSheetName, String Environment)
//	{
//
//		if (UseCommonMockSheet.toUpperCase().trim() == "YES")
//		{
//			return CommonMockSheetName;
//		}
//		else
//		{
//			return Environment;
//		}
//	}

	/// <summary>
	/// This method will set the Directory path for the Artifacts Folder
	/// Author: Jigesh Shah
	/// </summary>
	/// <param name="SetCustomPath">Yes/No</param>
	/// <param name="CustomPath">Set Custom Path if the value is set to 'Yes' in the SetCustomPath Argument </param>
	/// <returns>Sets and returns the Directory path for the Artifacts Folder </returns>
//	public String setArtifactsPath(String SetCustomPath, String CustomPath) throws Exception
//	{
//		try
//		{
//			if (SetCustomPath.toUpperCase().trim().equalsIgnoreCase("YES"))
//			{
//				return prop.getProperty("ArtifactsPath");
//			}
//			else
//			{
//				return TestRunSettings.HomePath + prop.getProperty("DefaultArtifactLocation");
//			}
//
//		}
//		catch (Exception e)
//		{
//			logger.info("Failed to Initialize the Artifacts Path");
//			System.out.println("Failed to Initialize the Artifacts Path");
//			System.out.println(e.getMessage());
//			System.out.println("StackTrace:"+e.getStackTrace());
//			logger.info(e.getMessage());
//			logger.info("StackTrace:"+e.getStackTrace());
//			throw new Exception("Failed to Initialize the Artifacts Path");
//
//		}
//	}

	/// <summary>
	/// This method will return true/false if Driver Config needs to be loaded
	/// </summary>
	/// <returns></returns>
	public boolean loadDriverDetails() throws Exception
	{
		try
		{
			if (prop.getProperty("LoadDriverOptions").toUpperCase().trim() == "YES")
			{
				return true;
			}
			else
			{
				return false;
			}

		}
		catch (Exception e)
		{
			logger.info("Failed to Initialize the Driver Load Details");
			System.out.println("Failed to Initialize the  Driver Load Details");
			System.out.println(e.getMessage());
			System.out.println("StackTrace:"+e.getStackTrace());
			logger.info(e.getMessage());
			logger.info("StackTrace:"+e.getStackTrace());
			throw new Exception("Failed to Initialize the  Driver Load Details");

		}
	}

	/// <summary>
	/// This mmethod will return the Directory Path where the results files will be stored
	/// Author: Jigesh Shah
	/// </summary>
	/// <returns>Results Directory Path</returns>
	public String getResultsPath() throws Exception
	{
		try
		{
			if (prop.getProperty("SetCustomResultLocation").toUpperCase().trim().equals("YES"))
			{
				File dir = new File(prop.getProperty("CustomResultLocation")+ "/"+  Util.getCurrentDate() + "/Run_" +  Util.getCurrentTime());
	            if (!dir.exists()) dir.mkdirs();
				return prop.getProperty("CustomResultLocation")+ "/"+  Util.getCurrentDate() + "/Run_" +  Util.getCurrentTime();
			}
			else
			{
				String ResultFolder= TestRunSettings.HomePath + "/" + prop.getProperty("DefaultResultLocation") + "/"+  Util.getCurrentDate() + "/Run_" +  Util.getCurrentTime();
				File dir = new File(ResultFolder);
	            if (!dir.exists()) dir.mkdirs();

	            
	            
				return ResultFolder;
			}

		}
		catch (Exception e)
		{
			logger.info("Failed to Initialize the Results Path");
			System.out.println("Failed to Initialize the Results Path");
			System.out.println(e.getMessage());
			System.out.println("StackTrace:"+e.getStackTrace());
			logger.info(e.getMessage());
			logger.info("StackTrace:"+e.getStackTrace());
			throw new Exception("Failed to Initialize the Results Path");

		}
	}

	/// <summary>
	/// This mmethod will return the Directory Path where the results files will be stored
	/// Author: Jigesh Shah
	/// </summary>
	/// <returns>Results Directory Path</returns>
//	public String getTempXMLPath(String resultPath) throws Exception
//	{
//		try
//		{
//				String ResultFolder=  resultPath + "\\TempTestCaseResults\\XMLTestCaseResults";
//				File dir = new File(ResultFolder);
//	            if (!dir.exists()) dir.mkdirs();
//
//
//
//				return ResultFolder;
//
//
//		}
//		catch (Exception e)
//		{
//			logger.info("Failed to Initialize the Results Path");
//			System.out.println("Failed to Initialize the Results Path");
//			System.out.println(e.getMessage());
//			System.out.println("StackTrace:"+e.getStackTrace());
//			logger.info(e.getMessage());
//			logger.info("StackTrace:"+e.getStackTrace());
//			throw new Exception("Failed to Initialize the Results Path");
//
//		}
//	}



	/// <summary>
	/// This mmethod will return the Directory Path where the results files will be stored
	/// Author: Jigesh Shah
	/// </summary>
	/// <returns>Results Directory Path</returns>
//	public String getTempJSONPath(String resultPath) throws Exception
//	{
//		try
//		{
//				String ResultFolder=  resultPath + "\\TempTestCaseResults\\JSONTestCaseResults";
//				File dir = new File(ResultFolder);
//	            if (!dir.exists()) dir.mkdirs();
//
//
//
//				return ResultFolder;
//
//
//		}
//		catch (Exception e)
//		{
//			logger.info("Failed to Initialize the Results Path");
//			System.out.println("Failed to Initialize the Results Path");
//			System.out.println(e.getMessage());
//			System.out.println("StackTrace:"+e.getStackTrace());
//			logger.info(e.getMessage());
//			logger.info("StackTrace:"+e.getStackTrace());
//			throw new Exception("Failed to Initialize the Results Path");
//
//		}
//	}
//
//
//	/// <summary>
//	/// This mmethod will return the Directory Path where the results files will be stored
//	/// Author: Jigesh Shah
//	/// </summary>
//	/// <returns>Results Directory Path</returns>
//	public String getTempExcelPath(String resultPath) throws Exception
//	{
//		try
//		{
//				String ResultFolder=  resultPath + "\\TempTestCaseResultsRExcelTestCaseResults";
//				File dir = new File(ResultFolder);
//	            if (!dir.exists()) dir.mkdirs();
//
//
//
//				return ResultFolder;
//
//
//		}
//		catch (Exception e)
//		{
//			logger.info("Failed to Initialize the Results Path");
//			System.out.println("Failed to Initialize the Results Path");
//			System.out.println(e.getMessage());
//			System.out.println("StackTrace:"+e.getStackTrace());
//			logger.info(e.getMessage());
//			logger.info("StackTrace:"+e.getStackTrace());
//			throw new Exception("Failed to Initialize the Results Path");
//
//		}
//	}
//


//	public void setHomePath(String currHomePath)
//	{
//		TestRunSettings.HomePath = currHomePath;
//	}
//	public void setResultFolderPath(String strResultsFolderPath)
//	{
//		TestRunSettings.ResultsFolderPath = strResultsFolderPath;
//	}



}
