package Reusable;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class CustomDate {
	
	public String CustomDate(String trDate,int Days,int Months,int Years) throws Exception 
    {
          try 
          {
        	  DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");        
        	    LocalDate tradeDate= LocalDate.parse(trDate, DateTimeFormatter.ofPattern("MM/dd/yyyy"));
        	  
                  tradeDate= tradeDate.plusMonths(Months);
                 
                  
                 tradeDate=tradeDate.plusDays(Days);
                 tradeDate=tradeDate.plusYears(Years);
                 
                  String CustomDate=tradeDate.format(DateTimeFormatter.ofPattern("MM/dd/yyyy")).toString();
          System.out.println("CustomDate="+CustomDate);
                       
                       return CustomDate;
          }
          
          catch(Exception e) 
          {
                 throw e;
          }
          
          

    }
}
