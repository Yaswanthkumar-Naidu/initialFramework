package Reusable;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import java.lang.Thread.UncaughtExceptionHandler;
@Aspect
public class ExceptionHandlingAspect implements UncaughtExceptionHandler {

    @Override
    public void uncaughtException(Thread t, Throwable e) {
        if (e instanceof ClassCastException) {
            handleClassCastException((ClassCastException) e);
        } else {
            // Handle other types of exceptions or log them as needed
            e.printStackTrace();
        }
    }

    private void handleClassCastException(ClassCastException ex) {
        System.out.println("Caught ClassCastException globally: " + ex.getMessage());
        // Add your handling logic here if needed
    }

	
	
	
	
	
//	private long startTime;
//	 @After("execution(* org.openqa.selenium.WebDriver.get(..))")
//	    public void capturePageLoadTime() {
//	        long pageLoadTime = System.currentTimeMillis() - startTime;
//	        System.out.println("Page load time: " + pageLoadTime + " milliseconds");
//	    }
//
//	    @AfterThrowing(pointcut = "execution(* *(..))", throwing = "ex")
//	    public void handleClassCastException(ClassCastException ex) {
//	        System.out.println("Caught ClassCastException: " + ex.getMessage());
//	        // Add your handling logic here if needed
//	    }
//	    @After("execution(* *(..)) && !execution(* org.openqa.selenium.WebDriver.get(..))")
//	    public void captureStartTime() {
//	        startTime = System.currentTimeMillis();
//	    }

}

