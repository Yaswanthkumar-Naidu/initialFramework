package Reusable;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;  
import net.rationalminds.LocalDateModel;  
import net.rationalminds.Parser;

public class TimeTravelDate {
	private  WebDriver driver;
	
	public TimeTravelDate(WebDriver _driver)
    {
        driver = _driver;
    }
	
	
	public String GetTimeTravelDate() throws Exception 
	{
		try {
			Thread.sleep(5000);
			//WebKeywords.Instance().WaitElementVisible(driver, By.xpath("//*[@class='TimeTravelDateDisplay subHeadingStyle']"), 5000);
			LocalDate date = LocalDate.now();
			String Date=date.format(DateTimeFormatter.ofPattern("MM/dd/yyyy")).toString();
            LocalDate TTDate= LocalDate.parse(Date, DateTimeFormatter.ofPattern("MM/dd/yyyy"));
            String ApplicationDate="";
		 if(driver.findElements(By.xpath("//*[@class='TimeTravelDateDisplay subHeadingStyle']")).size()>0) 
       {
   		ApplicationDate=  driver.findElement(By.xpath("//*[@class='TimeTravelDateDisplay subHeadingStyle']")).getText().replace("Time Travel Date ", "").toString();  	   
       }
       else 
       {
    	ApplicationDate=TTDate.format(DateTimeFormatter.ofPattern("MM/dd/yyyy")).toString(); 
       }
		  
		return ApplicationDate;
		}
		catch(Exception e)
		{
			throw e;			
		}
				
    }
	
	
}
