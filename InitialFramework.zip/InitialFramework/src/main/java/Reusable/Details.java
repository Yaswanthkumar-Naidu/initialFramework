package Reusable;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;



public class Details
    {
        private WebDriver driver;
       
        public String[] FirstName()
        {
            String[] IndividualName = { };
            int RowCount1 = driver.findElements(By.xpath("//*[@class='even']")).size();
            int RowCount2 = driver.findElements(By.xpath("//*[@class='odd']")).size();
            int RowCount = RowCount1 + RowCount2;

            for(int i=0; i< RowCount; i++)
            {
                int j = i + 1;
                String Ind = driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[6]/div/div/div/div[2]/div[1]/form/div/div[1]/div[4]/div[2]/div/table/tbody/tr["+j+"]/td[1]")).getText();
				/*
				 * Array.Resize(ref IndividualName, IndividualName.Length + 1);
				 * IndividualName[IndividualName.Length - 1] = Ind;
				 */
            }

            return IndividualName;
        }
    }
